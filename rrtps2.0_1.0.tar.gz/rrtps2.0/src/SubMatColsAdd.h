#ifndef SUBMATCOLSADD_H_INCLUDED
#define SUBMATCOLSADD_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericMatrix MatColsAdd(Rcpp::NumericMatrix inMatrix,Rcpp::IntegerVector HrMarks);

#endif // SUBMATCOLSADD_H_INCLUDED
