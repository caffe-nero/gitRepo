//' This is the .main function for the rrtps library.
//' In a nutshell , this function identifies all smoothed price (VecToSaddle) points that come after a cross over between cumulative activity data.
//' The assumption is that continuous interaction between market players leads to activity regimes (see OIR) which influence the outlook of market players
//' leading to perceptions that influence players in taking positions, trading.
//' The function helps to create features from the data at hand that is input to ML algorithms used for price prediction.
//' MAXIMA | MINIMA         : All evaluation of PRICE at VTS turning points.
//' REL_MAXIMA | REL_MINIMA : Relative changes in 2 homogeneous successive turning points, say at 2 adjacent Maxima points.
//'
//'@param VecToSaddle denotes  k-fold cross validation cumulative MidPrice trend.
//'@param csum_vol_D  denoting cumulative activity data on volume demanded.
//'@param csum_vol_S  denoting cumulative activity data on volume supplied.
//'@param vol_D that represents volume demanded at a time-point i.
//'@param vol_S that represents volume supplied at a time-point i.
//'@param Price denotes MidPrice observed at a time-point i.
//'@param Residual_vD denoting portion of demand in the market that is not fulfilled by supply, at time-spot i.
//'@param Residual_vS denoting portion of supply in the market that is not fulfilled by demand, at time-spot i.
//'
//'@examples
//' NumericVector VecToSaddle,NumericVector csum_vol_D, NumericVector csum_vol_S, NumericVector vol_D, NumericVector vol_S, NumericVector Price , NumericVector Residual_vD, NumericVector Residual_vS )
//'@return features listing evaluated at various VTS turning points, for both MAXIMA and MINIMA.

#include <cmath>
#include <Rcpp.h>
#include "c_crossOvers.h"
#include "c_diff.h"
#include "c_dim.h"
#include "c_maxima_count.h"
#include "c_minima_count.h"
#include "c_non_zero_Cols.h"
#include "c_non_zero_Rows.h"
#include "c_rateOfChange.h"
#include "c_RSI.h"
#include "c_sign.h"
#include "c_squeeze_matrix_to_array.h"
#include "c_subset.h"
#include "c_unique_int_2.h"
#include "c_Which_XinY.h"
#include "nonZero_for_Zero.h"
#include "SubMatColsAdd.h"
#include "TradedVolume.h"
#include <numeric>
#include "utils.h"
#include "OIR.h"

using namespace Rcpp;


//[[Rcpp::export]]

Rcpp::NumericMatrix squeeze_correct(Rcpp::NumericMatrix inMatrix , Rcpp::IntegerVector TurningPts){

int matRows, matCols = 0;

matRows = inMatrix.nrow();

matCols = inMatrix.ncol();

NumericMatrix outMatrix(matRows,matCols);

if(TurningPts.size() != matRows){

    throw Rcpp::exception("Length of TurningPts and inMatrix-rows must be equal!!");

}else{


// copy inMatrix to outMatrix.

  for(int m=0;m<matRows;m++){

    for(int n=0;n<matCols;n++){

      outMatrix(m,n) = inMatrix(m,n);
    }

  }


 for(int j=1; j < outMatrix.nrow();j++){ //looping rows

   if(TurningPts[j-1]==TurningPts[j]) {

      for(int k=1; k<matCols ; k++){

        outMatrix(j-1,k) = inMatrix(j-1,k)/2.0;

        outMatrix(j,k)   = inMatrix(j,k)/2.0;
      }

   }

 }

}//if
return outMatrix;

}

// [[Rcpp::export]]

List saddles(NumericVector VecToSaddle,NumericVector csum_vol_D, NumericVector csum_vol_S, NumericVector vol_D, NumericVector vol_S,

             NumericVector Price , NumericVector Residual_vD, NumericVector Residual_vS ){

NumericVector temp_rated_Price = c_rateOfChange(Price); // For creating rates of change at MAXIMA and MINIMA points.

NumericVector to_acc_rated_Price(Price.size());

for(int i =0; i< Price.size();i++){

    to_acc_rated_Price[i] = round(10000*temp_rated_Price[i])/10000;

}

NumericVector rated_Price(to_acc_rated_Price.size());

std::partial_sum(to_acc_rated_Price.begin(),to_acc_rated_Price.end(),rated_Price.begin());

IntegerVector crossOverPts;

crossOverPts=c_crossOvers(csum_vol_D,csum_vol_S);

crossOverPts.push_back( VecToSaddle.size()-1 );   //see note 3 above in the comments section.

int n_Row=crossOverPts.size()-1;

IntegerVector maxCol_pts;
maxCol_pts=c_maxima_count(VecToSaddle,crossOverPts);

IntegerVector minCol_pts;
minCol_pts=c_minima_count(VecToSaddle,crossOverPts);

int maxCol=maxCol_pts.size();

int minCol=minCol_pts.size();

//Accumulating Residuals and Volumes for utilization determination

NumericVector acc_Res_vD(Residual_vD.size());
NumericVector acc_Res_vS(Residual_vS.size());

NumericVector acc_vol_D (vol_D.size());
NumericVector acc_vol_S (vol_S.size());

std::partial_sum(Residual_vD.begin(),Residual_vD.end(),acc_Res_vD.begin());

std::partial_sum(Residual_vS.begin(),Residual_vS.end(),acc_Res_vS.begin());

std::partial_sum(vol_D.begin(),vol_D.end(),acc_vol_D.begin());

std::partial_sum(vol_S.begin(),vol_S.end(),acc_vol_S.begin());

NumericVector settled_vD(vol_D.size());
NumericVector settled_vS(vol_S.size());

double temp1=0.0;

for(int i=0;i<vol_D.size();i++){

  temp1 = 1 - round(10000*acc_Res_vD[i] / acc_vol_D[i])/10000;

  settled_vD[i] = temp1;     // settled  =  accumulated_residuals / accumulated volume , intuitively what's not settled; non_settled. settled would thus = 1- non_settled
}

temp1=0.0;

for(int i=0;i<vol_S.size();i++){

 temp1 = 1 - round(10000*acc_Res_vS[i]/acc_vol_S[i] )/10000;

 settled_vS[i] = temp1;

}
//output matrices:
NumericMatrix Maxima(n_Row,VecToSaddle.size());

NumericMatrix Minima(n_Row,VecToSaddle.size());

NumericMatrix Rel_Maxima(n_Row,VecToSaddle.size());

NumericMatrix Rel_Minima(n_Row,VecToSaddle.size());

NumericMatrix grad_Vd_Maxi(n_Row,VecToSaddle.size());

NumericMatrix grad_Vs_Maxi(n_Row,VecToSaddle.size());

NumericMatrix grad_Vd_Mini(n_Row,VecToSaddle.size());

NumericMatrix grad_Vs_Mini(n_Row,VecToSaddle.size());

NumericMatrix OIR_Maxima(n_Row,VecToSaddle.size());

NumericMatrix OIR_Minima(n_Row,VecToSaddle.size());

NumericMatrix ROC_Maxima (n_Row , VecToSaddle.size()); //MAXIMA values expressed as % changes

NumericMatrix ROC_Minima (n_Row , VecToSaddle.size()); //MINIMA values expressed as % changes

NumericMatrix vD_Maxima (n_Row,VecToSaddle.size());
NumericMatrix vS_Maxima (n_Row,VecToSaddle.size());

NumericMatrix vD_Minima (n_Row,VecToSaddle.size());
NumericMatrix vS_Minima (n_Row,VecToSaddle.size());

NumericMatrix util_vD_Maxima   (n_Row, VecToSaddle.size()); // demand uptake at MAXIMA points.
NumericMatrix util_vS_Maxima   (n_Row, VecToSaddle.size()); // supply uptake at MAXIMA points.

NumericMatrix util_vD_Minima   (n_Row, VecToSaddle.size()); // demand uptake at MINIMA points.
NumericMatrix util_vS_Minima   (n_Row, VecToSaddle.size()); // supply uptake at MINIMA points.

IntegerVector Maxi_saddleCrossover;

IntegerVector Mini_saddleCrossover;

//For assurance purposes
IntegerVector Testing_pRAp_start;

NumericVector Testing_tempVTS;

NumericVector Testing_sadTest;

int startPt=0;

int sadChecker=0;  //just a Temp

IntegerVector negTpts;

IntegerVector povTpts;

IntegerVector MAXI_lastRow_written;
IntegerVector MINI_lastRow_written;

  if( (maxCol > 0) | (minCol > 0) ){ //if there's at least 1 saddle in a crossover range:

    for(int m=1;m<crossOverPts.size();m++){

    /* Elongating saddleFold by two ...at the beginning..
       .. to cater for the shorter by 2 resultant vector after c_diff(c_sign(c_diff(tempVTS_saddle)))                                                               =======================================
   */
    if(crossOverPts[m-1]>1){

       startPt=crossOverPts[m-1]-2;

    }else{

    startPt=crossOverPts[m-1];

    }
    IntegerVector saddleFold=Range(startPt,crossOverPts[m]);

    int temp_pRAp_start=crossOverPts[m-1];                  // start of current crossover range being considered.

    Testing_pRAp_start.push_back(temp_pRAp_start); //#Tested OK

    NumericVector tempVTS_saddle;

    tempVTS_saddle=VecToSaddle[saddleFold];

 //Testing_tempVTS.push_back(tempVTS_saddle);

        for(int xx=0;xx<tempVTS_saddle.size();xx++){

        Testing_tempVTS.push_back(tempVTS_saddle [xx] );
    }

  NumericVector sad_test  = c_diff(c_sign(c_diff(tempVTS_saddle)))   ;

  for(int xf=0;xf<sad_test.size();xf++){

    Testing_sadTest.push_back(sad_test[xf]);
  }
  /*looping through sad_test to isolate minima and maxima points along sad_test:
    Recall : sad_test = c_diff(c_sign(c_diff(tempVTS_saddle))) . sad_test is local to tempVTS_saddle !
 */

//maximas:

for(int pos_pts=0; pos_pts<sad_test.size();pos_pts++){

    if(sad_test[pos_pts]== 2 ){                                // MAXIMA Turning Point test.

        int colSpot=pos_pts+temp_pRAp_start;                  // colSpot is most current saddle time-step.

        int MAXI_Row_written = m-1;                              // if sadTest[n] !=0 , capture column written to.

        //  Maxima(m-1,colSpot)=  round(1000*VecToSaddle[colSpot])/1000;

           Maxima    (m-1,colSpot)=  round(1000*Price[colSpot])/1000;     //22-01-2020

           ROC_Maxima(m-1,colSpot) = round(10000*rated_Price[colSpot])/10000;    //  ROC_Minima(m-1,min_colSpot) = round(10000*rated_Price[min_colSpot])/10000;

           vD_Maxima (m-1, colSpot) = round(1000*vol_D[colSpot])/1000;

           vS_Maxima (m-1, colSpot) = round(1000*vol_S[colSpot])/1000;

           util_vD_Maxima(m-1, colSpot) = round(10000*settled_vD[colSpot])/10000;

           util_vS_Maxima(m-1, colSpot) = round(10000*settled_vS[colSpot])/10000;
/*
           condition comparing equal adjacent saddle points pointing back to 2 different crossover points and attributing
           the saddle points to the same former crossover point.
*/
          if ((temp_pRAp_start+pos_pts) == povTpts[povTpts.size()-1] ){ // if saddle_point_now == saddle_point_previous ..

            sadChecker= Maxi_saddleCrossover[Maxi_saddleCrossover.size()-1];  // ..they both belong to the same crossover start.

          }else{

            sadChecker=crossOverPts[m-1];                               //  ..current crossover start.
          }
            Maxi_saddleCrossover.push_back(sadChecker);
          //Maxi_saddleCrossover.push_back(crossOverPts[m-1]);                 // capture crossover yielding this current maxima turning point.
            sadChecker=0;  //clear value for reuse in MINIMA.

//      Writing Rel_Maxima:

            if(povTpts.size()>0){     // If there's at least 1 maxima turning point recorded ..

               int prev_colSpot=povTpts[ povTpts.size()-1]; // previous saddle time-step.

               int prev_rowSpot=MAXI_lastRow_written[ MAXI_lastRow_written.size()-1 ];    // previous maxima row written to...

               double aNum_r=Maxima(m-1,colSpot)-Maxima(prev_rowSpot,prev_colSpot);      // Numerator in change calc.
               //double aDen_r=Maxima(prev_rowSpot,prev_colSpot);                          //Denominator in change calc.

               double aDen_r=1.0; // Adjustment for difference calculation and NOT rate of change.

               Rel_Maxima(m-1,colSpot)=round(10000*aNum_r)/(10000*aDen_r); //Relative TIMES - changes between 2 maxima turning points.

               // ** grad_Vd_Maxima

               double max_delta_Y,max_delta_T =0.0;

               max_delta_Y = vol_D[colSpot]- vol_D[prev_colSpot];
               max_delta_T = vol_D[prev_colSpot];

               //grad_Vd_Maxi(m-1,colSpot)=round(1000*max_delta_Y)/(1000*max_delta_T);

               if((Rcpp::traits::is_nan<REALSXP>( round(1000*max_delta_Y)/(1000*max_delta_T) )) || (Rcpp::traits::is_infinite<REALSXP>( round(1000*max_delta_Y)/(1000*max_delta_T) ))){

                 grad_Vd_Maxi(m-1,colSpot)=0.0;

                } else{

                    grad_Vd_Maxi(m-1,colSpot)=round(1000*max_delta_Y)/(1000*max_delta_T);

                }

               // **grad_Vs_Maxima

               max_delta_T=0.0;
               max_delta_Y=0.0;

               max_delta_Y = vol_S[colSpot]-vol_S[prev_colSpot];
               max_delta_T = vol_S[prev_colSpot];

               //grad_Vs_Maxi(m-1,colSpot)=round(1000*max_delta_Y)/(1000*max_delta_T);
             // Overwriting IS_NAN and  IS_INFINITE
            if((Rcpp::traits::is_nan<REALSXP>( round(1000*max_delta_Y)/(1000*max_delta_T) )) || (Rcpp::traits::is_infinite<REALSXP>( round(1000*max_delta_Y)/(1000*max_delta_T) ))){

                grad_Vs_Maxi(m-1,colSpot)=0.0;

            }else{

                grad_Vs_Maxi(m-1,colSpot)=round(1000*max_delta_Y)/(1000*max_delta_T);
            }

            }//if povTpts

        //OIR_Maxima(m-1,colSpot)=round(1000*vol_D[colSpot]/( vol_D[colSpot] + vol_S[colSpot] ))/1000;

         if(  (Rcpp::traits::is_nan<REALSXP>( round(1000*vol_D[colSpot]/( vol_D[colSpot] + vol_S[colSpot] ))/1000  )) || (Rcpp::traits::is_infinite<REALSXP>( round(1000*csum_vol_D[colSpot]/( csum_vol_D[colSpot] + csum_vol_S[colSpot] ))/1000  ))){

               OIR_Maxima(m-1,colSpot)=0.0;

         }else{
                OIR_Maxima(m-1,colSpot)=round(1000*vol_D[colSpot]/( vol_D[colSpot] + vol_S[colSpot] ))/1000;
         }

        MAXI_lastRow_written.push_back(MAXI_Row_written);          //keeps a record of rows last written to.

        povTpts.push_back(pos_pts+temp_pRAp_start); //Keeps a record of Maxima turning points ..
    }
}

//minimas

for(int neg_pts=0;neg_pts<sad_test.size();neg_pts++){

    if(sad_test[neg_pts]== -2 ){                                     // MINIMA turning point test

        int min_colSpot=neg_pts+temp_pRAp_start;                  // colSpot = most current saddle time-step.

        int MINI_Row_written = m-1;                                  // if sadTest[n] !=0 , capture column written to.

        // Minima(m-1,min_colSpot)=round(1000*VecToSaddle[min_colSpot])/1000;

        Minima(m-1,min_colSpot)=round(1000*Price[min_colSpot])/1000;       // 22-01-2020

        ROC_Minima(m-1,min_colSpot) = round(10000*rated_Price[min_colSpot])/10000; //market %

        vD_Minima(m-1,min_colSpot) = round (1000* vol_D[min_colSpot])/1000;

        vS_Minima(m-1,min_colSpot) =  round(1000* vol_S[min_colSpot])/1000;

        util_vD_Minima(m-1,min_colSpot) = round(10000*settled_vD[min_colSpot])/10000;

        util_vS_Minima(m-1,min_colSpot) = round(10000*settled_vS[min_colSpot])/10000;

        /*
           condition comparing equal adjacent saddle points pointing back to 2 different crossover points and attributing
           the saddle points to the same former crossover point.
*/
         if ((temp_pRAp_start+neg_pts) == negTpts[negTpts.size()-1] ){ // if saddle_point_now == saddle_point_previous ..

            sadChecker = Mini_saddleCrossover[Mini_saddleCrossover.size()-1];  // ..they both belong to the same crossover start.

          }else{

            sadChecker=crossOverPts[m-1];                               //  ..current crossover start.
          }

          Mini_saddleCrossover.push_back(sadChecker);                  // // capture crossover yielding this current minima turning point.

        //Mini_saddleCrossover.push_back(crossOverPts[m-1]);
        //Writing Rel_Minima

         if(negTpts.size()>0){     // If there's at least 1 minima turning point recorded ..

               int min_prev_colSpot=negTpts[ negTpts.size()-1]; // previous saddle time-step.

               int min_prev_rowSpot=MINI_lastRow_written[ MINI_lastRow_written.size()-1 ];    // previous minima row written to...

               double min_aNum_r=Minima(m-1,min_colSpot)-Minima(min_prev_rowSpot,min_prev_colSpot);      // Numerator in change calc.
               //double min_aDen_r=Minima(min_prev_rowSpot,min_prev_colSpot);                          //Denominator in change calc.

               double min_aDen_r =  1.0; //To ensure Rel_Minima is a price difference and not ROC.

               Rel_Minima(m-1,min_colSpot)=round(1000*min_aNum_r)/(1000*min_aDen_r); //Relative TIMES - changes between 2 minima turning points.

               // writing  to grad_Vd_mini and grad_Vs_mini

               double min_delta_Y,min_delta_T =0.0;

               min_delta_Y = vol_D[min_colSpot]-vol_D[min_prev_colSpot];
               min_delta_T = vol_D[min_prev_colSpot];

               //grad_Vd_Mini(m-1,min_colSpot)=round(1000*min_delta_Y)/(1000*min_delta_T);

               //Handling is_nan and is_infinite.
               if( (Rcpp::traits::is_nan<REALSXP> (round(1000*min_delta_Y)/(1000*min_delta_T))) || (Rcpp::traits::is_infinite<REALSXP> (round(1000*min_delta_Y)/(1000*min_delta_T)))){

                    grad_Vd_Mini(m-1,min_colSpot) = 0.0;

               }else{

                    grad_Vd_Mini(m-1,min_colSpot) = round(1000*min_delta_Y)/(1000*min_delta_T);
               }

                min_delta_T=0.0;
                min_delta_Y=0.0;

                min_delta_Y = vol_S[min_colSpot]-vol_S[min_prev_colSpot];
                min_delta_T = vol_S[min_prev_colSpot];

                //grad_Vs_Mini(m-1,min_colSpot)=round(1000*min_delta_Y)/(1000*min_delta_T);
                //Handling is_nan and is_infinite.

              if(  (Rcpp::traits::is_nan<REALSXP>( round(1000*min_delta_Y)/(1000*min_delta_T) )) || ( Rcpp::traits::is_infinite<REALSXP>( round(1000*min_delta_Y)/(1000*min_delta_T)    )   ) ){

                   grad_Vs_Mini(m-1,min_colSpot)=0.0;

              }else{

                   grad_Vs_Mini(m-1,min_colSpot)=round(1000*min_delta_Y)/(1000*min_delta_T);
              }

            }

        //OIR_Minima(m-1,min_colSpot)= round(1000*vol_D[min_colSpot]/(vol_D[min_colSpot] + vol_S[min_colSpot]))/1000 ;

      if(  (Rcpp::traits::is_nan<REALSXP> ( round(1000*vol_D[min_colSpot]/(vol_D[min_colSpot] + vol_S[min_colSpot]))/1000 )) || (Rcpp::traits::is_infinite<REALSXP> ( round(1000*vol_D[min_colSpot]/(vol_D[min_colSpot] + vol_S[min_colSpot]))/1000 ))){

             OIR_Minima(m-1,min_colSpot)=0.0;
      }else{

            OIR_Minima(m-1,min_colSpot)= round(1000*vol_D[min_colSpot]/(vol_D[min_colSpot] + vol_S[min_colSpot]))/1000 ;
      }

        MINI_lastRow_written.push_back(MINI_Row_written);          //keeps a record of row last written to.

        negTpts.push_back(neg_pts+temp_pRAp_start);
    }
}

    }//m

}//endif

Rcpp::List Maxima_List(10);

Rcpp::List Minima_List(10);

Maxima_List = Rcpp::List::create(Named("Rel_Maxima"    ,    Rel_Maxima  ),   //  Relative Turning point price Delta
                                 Named("cum_Rated_Max" ,     ROC_Maxima ),   //  Market cum price change %
                                 Named("grad_Vd_Maxi"  ,  grad_Vd_Maxi  ),   //  ROC_Vol_D
                                 Named("grad_Vs_Maxi"  ,  grad_Vs_Maxi  ),   //  ROC_Vol_S
                                 Named("OIR_Maxima"    ,    OIR_Maxima  ),   //  OIR
                                 Named("Max_Perform"   ,    Maxima      ),   //  Price
                                 Named("Max_vol_D"     ,    vD_Maxima   ),   //  Vol_D
                                 Named("Max_vol_S"     ,    vS_Maxima   ),   //  Vol_S
                                 Named("Max_Util_vD"   ,  util_vD_Maxima),   //  Demand uptake
                                 Named("Max_Util_vS"   ,  util_vS_Maxima)    //  Supply uptake

                                 );

Minima_List = Rcpp::List::create(Named("Rel_Minima"   ,     Rel_Minima),   //  Relative Turning Point price Delta
                                 Named("cum_Rated_Min",     ROC_Minima),   //  Market cum price change %
                                 Named("grad_Vd_Mini" ,   grad_Vd_Mini),   //  ROC_Vol_D
                                 Named("grad_Vs_Mini" ,   grad_Vs_Mini),   //  ROC_Vol_S
                                 Named("OIR_Minima"   ,     OIR_Minima),   //  OIR
                                 Named("Min_Perf."    ,         Minima),   //  Price
                                 Named("Min_vol_D"    ,      vD_Minima),   //  Vol_D
                                 Named("Min_vol_S"    ,      vS_Minima),   //  Vol_S
                                 Named("Min_Util_vD"  , util_vD_Minima),   //  Demand uptake
                                 Named("Min_Util_vS"  , util_vS_Minima)    //  Supply uptake

                                 );

NumericMatrix MAXA(povTpts.size(), Maxima_List.size());

NumericMatrix MINI(negTpts.size(), Minima_List.size());

//squeezing ...

MAXA = c_squeeze_matrix_to_array(Maxima_List , povTpts);

MINI = c_squeeze_matrix_to_array(Minima_List , negTpts);

NumericMatrix MAXA_correct(MAXA.nrow(),MAXA.ncol());

NumericMatrix MINI_correct(MINI.nrow(), MINI.ncol());


MAXA_correct = squeeze_correct(MAXA,povTpts);

MINI_correct = squeeze_correct(MINI,negTpts);

return Rcpp::List::create(

                          Named("Maxima Saddles"         ,               povTpts),
                          Named("MAXA_Saddle_CrossOvers" ,  Maxi_saddleCrossover),
                          Named("Minima Saddles"         ,               negTpts),
                          Named("MINI_Saddle_CrossOvers" ,  Mini_saddleCrossover),
                          Named("MAXA"                   ,          MAXA_correct),
                          Named("MINI"                   ,          MINI_correct)

                          );

}
