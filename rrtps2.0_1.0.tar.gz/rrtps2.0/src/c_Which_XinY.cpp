// ' This function returns values forming the intersection between two vectors.
// ' It returns the values of elements in Vector_1 that are present in another vector, Vector_2.
//'  @param VecX
//'  @param VecY

//'  @examples
//'  c_WhichXinY( VecX , VecY )

//'  @return vector of intersection elements.


# include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]

Rcpp::IntegerVector c_Which_XinY(Rcpp::IntegerVector VecX,Rcpp::IntegerVector VecY){

int a=VecX.size();

int b=VecY.size();

IntegerVector outputVec;


for(int i=0;i<a;i++){

    for(int j=0; j<b ; j++){

        if(VecX[i]==VecY[j]){

            outputVec.push_back(i);
        }

    }

}


return outputVec;

}
