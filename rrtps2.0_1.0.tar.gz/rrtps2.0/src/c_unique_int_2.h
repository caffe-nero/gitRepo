#ifndef C_UNIQUE_INT_2_H_INCLUDED
#define C_UNIQUE_INT_2_H_INCLUDED

#include <Rcpp.h>

Rcpp::IntegerVector c_unique_int_2(Rcpp::IntegerVector in_Vector);

#endif // C_UNIQUE_INT_2_H_INCLUDED
