
// ' This function replicates the base function sign().

// ' This is an indicator function that receives a numeric vector of values and signs all elements as either { + , 0 , - }.

//'  @param nVec

//'  @examples
//'  c_sign( nVec  )

//'  @return a signed elements of nVec in a vector.

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]

Rcpp::NumericVector c_sign(Rcpp::NumericVector nVec) {

 int nVecSize=nVec.size();

  NumericVector signVec(nVecSize);

  for(int k=0;k<nVecSize;k++){

    if(nVec[k]==0.0){

      signVec[k]=0.0;
    }


    if(nVec[k]>0.0){

      signVec[k]=1.0;
    }


    if(nVec[k]<0.0){

      signVec[k]=0.0-1.0;
    }


  }

  return signVec;

}
