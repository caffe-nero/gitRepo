// 'Greedy piece that gets a glimpse of position of MINIMA points in all crossOver points identified in 2 input vectors that form the series at hand.

//'  It returns a positional integer vector of MINIMA in crossOver splits of the VectorToSaddle.

//'  @param yVecToSaddle
//'  @param yCrossOver_Pts

//'  @example
//'  c_mimima_count( yVecToSaddle , yCrossOver_Pts )

//'  @return MINIMA points in crossOver split points of the vector with turning points.

#include <Rcpp.h>

#include "c_diff.h"

#include "c_sign.h"

using namespace Rcpp;

// [[Rcpp::export]]

Rcpp::IntegerVector c_minima_count(Rcpp::NumericVector yVecToSaddle, Rcpp::IntegerVector yCrossOver_Pts){

int yStartPt=0;


IntegerVector y_Negatives;

for(int ym=1;ym < yCrossOver_Pts.size(); ym++){


    /*Elongating saddleFold by two ...at the beginning..
       .. to cater for the shorter by 2 resultant vector after c_diff(c_sign(c_diff(tempVTS_saddle)))
                                                               =======================================
   */

    if(yCrossOver_Pts[ym-1] > 1){

       yStartPt=yCrossOver_Pts[ym-1]-2;

    }else{

       yStartPt=yCrossOver_Pts[ym-1];

    }

   // IntegerVector saddleFold=Range(crossOverPts[m-1],crossOverPts[m]);

    IntegerVector ysaddleFold=Range(yStartPt,yCrossOver_Pts[ym]);

   // int xtemp_pRAp_start=xCrossOver_Pts[xm-1];

    //Testing_pRAp_start.push_back(temp_pRAp_start); //#Tested OK

    NumericVector ytempVTS_saddle;

    ytempVTS_saddle=yVecToSaddle[ysaddleFold];

    IntegerVector y_sad_test;

    y_sad_test=c_diff(c_sign(c_diff(ytempVTS_saddle)));


    for(int ysadPts=0;ysadPts<y_sad_test.size();ysadPts++){


        if(y_sad_test[ysadPts]== -2){

            y_Negatives.push_back(yStartPt+ysadPts);

            }


    }//for ysadpts


   }//for ym


//return y_Negatives.size();

return y_Negatives;

}
