#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME:
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP _rrtps2_0_c_crossOvers(SEXP, SEXP);
extern SEXP _rrtps2_0_c_diff(SEXP);
extern SEXP _rrtps2_0_c_dim(SEXP);
extern SEXP _rrtps2_0_c_maxima_count(SEXP, SEXP);
extern SEXP _rrtps2_0_c_minima_count(SEXP, SEXP);
extern SEXP _rrtps2_0_c_non_zero_Cols(SEXP);
extern SEXP _rrtps2_0_c_non_zero_Rows(SEXP);
extern SEXP _rrtps2_0_c_rateOfChange(SEXP);
extern SEXP _rrtps2_0_c_RSI(SEXP, SEXP);
extern SEXP _rrtps2_0_c_sign(SEXP);
extern SEXP _rrtps2_0_c_squeeze_matrix_to_array(SEXP, SEXP);
extern SEXP _rrtps2_0_c_subset(SEXP, SEXP, SEXP);
extern SEXP _rrtps2_0_c_unique_int(SEXP);
extern SEXP _rrtps2_0_c_unique_int_2(SEXP);
extern SEXP _rrtps2_0_c_Which_XinY(SEXP, SEXP);
extern SEXP _rrtps2_0_dbl_Which_XinY(SEXP, SEXP);
extern SEXP _rrtps2_0_MatColsAdd(SEXP, SEXP);
extern SEXP _rrtps2_0_nonZero_for_Zero(SEXP);
extern SEXP _rrtps2_0_OIR(SEXP, SEXP);
extern SEXP _rrtps2_0_pair_invt_strategy(SEXP, SEXP);
extern SEXP _rrtps2_0_rcpp_hello_world();
extern SEXP _rrtps2_0_saddles(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _rrtps2_0_squeeze_correct(SEXP, SEXP);
extern SEXP _rrtps2_0_Tracking(SEXP);
extern SEXP _rrtps2_0_TradedVolume(SEXP, SEXP);
extern SEXP _rrtps2_0_utils(SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
    {"_rrtps2_0_c_crossOvers",              (DL_FUNC) &_rrtps2_0_c_crossOvers,              2},
    {"_rrtps2_0_c_diff",                    (DL_FUNC) &_rrtps2_0_c_diff,                    1},
    {"_rrtps2_0_c_dim",                     (DL_FUNC) &_rrtps2_0_c_dim,                     1},
    {"_rrtps2_0_c_maxima_count",            (DL_FUNC) &_rrtps2_0_c_maxima_count,            2},
    {"_rrtps2_0_c_minima_count",            (DL_FUNC) &_rrtps2_0_c_minima_count,            2},
    {"_rrtps2_0_c_non_zero_Cols",           (DL_FUNC) &_rrtps2_0_c_non_zero_Cols,           1},
    {"_rrtps2_0_c_non_zero_Rows",           (DL_FUNC) &_rrtps2_0_c_non_zero_Rows,           1},
    {"_rrtps2_0_c_rateOfChange",            (DL_FUNC) &_rrtps2_0_c_rateOfChange,            1},
    {"_rrtps2_0_c_RSI",                     (DL_FUNC) &_rrtps2_0_c_RSI,                     2},
    {"_rrtps2_0_c_sign",                    (DL_FUNC) &_rrtps2_0_c_sign,                    1},
    {"_rrtps2_0_c_squeeze_matrix_to_array", (DL_FUNC) &_rrtps2_0_c_squeeze_matrix_to_array, 2},
    {"_rrtps2_0_c_subset",                  (DL_FUNC) &_rrtps2_0_c_subset,                  3},
    {"_rrtps2_0_c_unique_int",              (DL_FUNC) &_rrtps2_0_c_unique_int,              1},
    {"_rrtps2_0_c_unique_int_2",            (DL_FUNC) &_rrtps2_0_c_unique_int_2,            1},
    {"_rrtps2_0_c_Which_XinY",              (DL_FUNC) &_rrtps2_0_c_Which_XinY,              2},
    {"_rrtps2_0_dbl_Which_XinY",            (DL_FUNC) &_rrtps2_0_dbl_Which_XinY,            2},
    {"_rrtps2_0_MatColsAdd",                (DL_FUNC) &_rrtps2_0_MatColsAdd,                2},
    {"_rrtps2_0_nonZero_for_Zero",          (DL_FUNC) &_rrtps2_0_nonZero_for_Zero,          1},
    {"_rrtps2_0_OIR",                       (DL_FUNC) &_rrtps2_0_OIR,                       2},
    {"_rrtps2_0_pair_invt_strategy",        (DL_FUNC) &_rrtps2_0_pair_invt_strategy,        2},
    {"_rrtps2_0_rcpp_hello_world",          (DL_FUNC) &_rrtps2_0_rcpp_hello_world,          0},
    {"_rrtps2_0_saddles",                   (DL_FUNC) &_rrtps2_0_saddles,                   8},
    {"_rrtps2_0_squeeze_correct",           (DL_FUNC) &_rrtps2_0_squeeze_correct,           2},
    {"_rrtps2_0_Tracking",                  (DL_FUNC) &_rrtps2_0_Tracking,                  1},
    {"_rrtps2_0_TradedVolume",              (DL_FUNC) &_rrtps2_0_TradedVolume,              2},
    {"_rrtps2_0_utils",                     (DL_FUNC) &_rrtps2_0_utils,                     2},
    {NULL, NULL, 0}
};

void R_init_rrtps2_0(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}

