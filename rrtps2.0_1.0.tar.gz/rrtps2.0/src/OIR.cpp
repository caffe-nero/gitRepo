// Planned to be added to the rrtps library after compilations as a RCPP based library.

// Also added to this new push is a utilization module ... to contribute to calculation of util_vD and util_vS.CMD

// 'This function receives a matrix of instantaneous Demand and Supply quantities and returns OIR per time-point T_i.

//'  @param Demand

//'  @param Supply

//'  @examples
//'  c_OIR( Demand , Supply )

//'  @Returns OIR variables given demand and supply quantities.

#include<cmath>
#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericMatrix OIR ( Rcpp::NumericMatrix Demand , Rcpp::NumericMatrix Supply){


int rows=Demand.nrow(), cols=Demand.ncol();

NumericMatrix OIR(rows,cols);

if ((Demand.nrow() != Supply.nrow()) || Demand.ncol() != Supply.ncol() ){

    throw Rcpp::exception ("Error --> Dimensions of Demand_Matrix and Supply_Matrix must match. Exiting ..!!");


} else{



for(int m=0 ; m<rows; m++){


    for(int n=0; n<cols; n++){

        if((Rcpp::traits::is_nan<REALSXP>(Demand(m,n)/(Demand(m,n) + Supply(m,n))))  ||  (Rcpp::traits::is_infinite<REALSXP>(Demand(m,n)/(Demand(m,n) + Supply(m,n))))){

            OIR(m,n) = 0.0;

        }else{

            double tempSum = Demand(m,n)/(Demand(m,n) + Supply(m,n));

            OIR(m,n) = round(10000*tempSum)/10000;

        }


    } // forLoop




}      // forLoop


} //end if

return OIR;
}

