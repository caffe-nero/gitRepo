#ifndef C_MAXIMA_COUNT_H_INCLUDED
#define C_MAXIMA_COUNT_H_INCLUDED

#include<Rcpp.h>

Rcpp::IntegerVector c_maxima_count(Rcpp::NumericVector xVecToSaddle, Rcpp::IntegerVector xCrossOver_Pts);

#endif // C_MAXIMA_COUNT_H_INCLUDED
