#ifndef DBL_WHICH_XINY_H_INCLUDED
#define DBL_WHICH_XINY_H_INCLUDED

#include <Rcpp.h>

Rcpp::IntegerVector dbl_Which_XinY(Rcpp::NumericVector VecX,Rcpp::NumericVector VecY);


#endif // DBL_WHICH_XINY_H_INCLUDED
