#ifndef PAIR_INVESTMENT_STRATEGY_H_INCLUDED
#define PAIR_INVESTMENT_STRATEGY_H_INCLUDED

#include<Rcpp.h>

Rcpp::DataFrame pair_invt_strategy(Rcpp::NumericVector PriceSeries, Rcpp::CharacterVector Tstamps );

#endif // PAIR_INVESTMENT_STRATEGY_H_INCLUDED
