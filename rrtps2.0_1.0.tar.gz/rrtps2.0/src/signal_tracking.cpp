#include<Rcpp.h>

#include"dbl_Which_XinY.h"

#include<cmath>

#include "c_rateOfChange.h"

/*
Tracks eventual performance of market calls given by system.

Input is a Price Vector.

This is the marking scheme after market has unfolded results over the prediction phase.

It basically says " This is how it should have been done at the onset of the prediction phase!".

*/

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::DataFrame Tracking(Rcpp::NumericVector PriceSeries){

//Rcpp::DataFrame Tracking(std::string mdl_pair, std::string mdl_strategy, double mdl_curPrc, double mdl_minPrc,double mdl_maxPrc,Rcpp::NumericVector PriceSeries){

int inSz = PriceSeries.size();

NumericVector MinPrice(1);
MinPrice[0]= PriceSeries[0];

NumericVector MaxPrice(1);
MaxPrice[0] = PriceSeries[0];

for(int i = 1; i<inSz; i++){

 if((PriceSeries[i] < PriceSeries[i-1]) && (PriceSeries[i] < MinPrice[0])){

    MinPrice[0] = PriceSeries[i];
 }

if((PriceSeries[i] > PriceSeries[i-1]) && (PriceSeries[i] > MaxPrice[0])){

    MaxPrice[0] = PriceSeries[i];
}

}

IntegerVector temp_MinPt = dbl_Which_XinY(PriceSeries,MinPrice);

IntegerVector temp_MaxPt = dbl_Which_XinY(PriceSeries,MaxPrice);

int currPt =0;
int minPt = temp_MinPt[0];
int maxPt = temp_MaxPt[0];

int entryPt = 0;

std::string strategy;

double vanilla = 0.0;

NumericVector ROC;

if((currPt == minPt) && (maxPt > currPt)){
    entryPt = currPt;
    strategy = "OutrightLong";
     vanilla = PriceSeries[maxPt] - PriceSeries[entryPt];
     NumericVector tempVec(2);
     tempVec[0] = PriceSeries[entryPt];
     tempVec[1] = PriceSeries[maxPt];
     ROC = c_rateOfChange(tempVec);

    }

if( (currPt == maxPt) && (minPt > currPt)){
    strategy = "OutrightShort";
    entryPt = currPt;
    NumericVector tempVec(2);
     tempVec[0] = PriceSeries[entryPt];
     tempVec[1] = PriceSeries[maxPt];
     ROC = c_rateOfChange(tempVec);
}

if( (currPt < minPt) && (maxPt > minPt)){
    strategy = "ShortLong";
    entryPt = minPt;
    vanilla = PriceSeries[maxPt] - PriceSeries[minPt];

     NumericVector tempVec(2);
     tempVec[0] = PriceSeries[entryPt];
     tempVec[1] = PriceSeries[maxPt];
     ROC = c_rateOfChange(tempVec);
}

if( (maxPt > currPt) && (minPt > maxPt)){
    strategy = "LongShort";
    entryPt = currPt;
    vanilla = PriceSeries[maxPt] - PriceSeries[currPt];

     NumericVector tempVec(2);
     tempVec[0] = PriceSeries[entryPt];
     tempVec[1] = PriceSeries[maxPt];
     ROC = c_rateOfChange(tempVec);

   }

   if((maxPt == currPt)&& minPt==currPt){
    strategy = "non-Entry";
   }



   double entryPrice = PriceSeries[currPt];

   double gain = ROC[ROC.size()-1];

Rcpp::List outList = Rcpp::List::create(strategy,entryPrice,MinPrice,MaxPrice,vanilla,gain);

Rcpp::CharacterVector df_names(6);

df_names[0] = "strategy";
df_names[1] = "entryPrice";
df_names[2] = "minPrice";
df_names[3] = "maxPrice";
df_names[4] = "change";
df_names[5] = "gain_pc";

outList.attr("names") = df_names;

Rcpp::DataFrame outDF(outList);


return outDF;
}
