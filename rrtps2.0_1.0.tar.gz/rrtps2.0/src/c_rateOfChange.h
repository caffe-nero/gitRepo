#ifndef C_RATEOFCHANGE_H_INCLUDED
#define C_RATEOFCHANGE_H_INCLUDED

Rcpp::NumericVector c_rateOfChange(Rcpp::NumericVector inVector);

#endif // C_RATEOFCHANGE_H_INCLUDED
