

// 'Greedy piece that gets a glimpse of position of MAXIMA points in all crossOver points identified in 2 input vectors that form the series at hand.

//'  It returns a positional integer vector of MAXIMA in crossOver splits of the VectorToSaddle.

//'  @param xVecToSaddle , xCrossOver_Pts

//'  @example
//'  c_maxima_count( xVecToSaddle , xCrossOver_Pts )

//'  @return MAXIMA points in crossOver split points of the vector with turning points.

#include <Rcpp.h>

#include "c_diff.h"

#include "c_sign.h"

using namespace Rcpp;

// [[Rcpp::export]]

Rcpp::IntegerVector c_maxima_count(Rcpp::NumericVector xVecToSaddle, Rcpp::IntegerVector xCrossOver_Pts){

int xStartPt=0;

IntegerVector x_Positives;

for(int xm=1;xm < xCrossOver_Pts.size(); xm++){


    /*Elongating saddleFold by two ...at the beginning..
       .. to cater for the shorter by 2 resultant vector after c_diff(c_sign(c_diff(tempVTS_saddle)))
                                                               =======================================
   */

    if(xCrossOver_Pts[xm-1] > 1){

       xStartPt=xCrossOver_Pts[xm-1]-2;

    }else{

       xStartPt=xCrossOver_Pts[xm-1];

    }

   // IntegerVector saddleFold=Range(crossOverPts[m-1],crossOverPts[m]);

    IntegerVector xsaddleFold=Range(xStartPt,xCrossOver_Pts[xm]);

   // int xtemp_pRAp_start=xCrossOver_Pts[xm-1];

    //Testing_pRAp_start.push_back(temp_pRAp_start); //#Tested OK

    NumericVector xtempVTS_saddle;

    xtempVTS_saddle=xVecToSaddle[xsaddleFold];

    IntegerVector x_sad_test;

    x_sad_test=c_diff(c_sign(c_diff(xtempVTS_saddle)));


    for(int xsadPts=0;xsadPts<x_sad_test.size();xsadPts++){

        if( x_sad_test[xsadPts]==2 ){

            x_Positives.push_back(xStartPt+xsadPts);
        }



    }//for xsadpts


}//xm

//return x_Positives.size();

return x_Positives;


}
