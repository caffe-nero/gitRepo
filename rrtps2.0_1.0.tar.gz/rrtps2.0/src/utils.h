#ifndef C_SUBSET_H_INCLUDED
#define C_SUBSET_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericMatrix utils(Rcpp::NumericMatrix surplus, Rcpp::NumericMatrix quantity);

#endif // C_SUBSET_H_INCLUDED
