// ' This function replicated the unique function() in base R but for integer vectors.
// '
//'  @param in_Vector

//'  @examples
//'  c_unique_int(in_Vector)

//'  @return unique elements in in_Vector.

#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::IntegerVector c_unique_int(Rcpp::IntegerVector in_Vector){

IntegerVector outVector;

for(int i=0; i < in_Vector.size() ; i++){

    if(in_Vector[i] != outVector[outVector.size()-1]){

        outVector.push_back( in_Vector[i] );
    }
}
return outVector;

}
