#ifndef C_SIGN_H_INCLUDED
#define C_SIGN_H_INCLUDED

#include <Rcpp.h>

Rcpp::NumericVector c_sign(Rcpp::NumericVector nVec);

#endif // C_SIGN_H_INCLUDED
