//' This function accepts matrices of Qty_Dd and Qty_Ss and tries to establish Volumes traded and pair residues unfulfilled in the market.

// ' The quantities are taken at a particular time-slot i.

//' Results are to be applied as cumulative sums (later , out of function) to establish trends in the 4 variables outputted.

//' cmath is for new c++. math.h is old C.
//' abs returns int. use std::abs to return floating point.
//' The algorithm in this function follows two leads :
//'     1). captures rethink around swelling up and crumbling down of walls. Volume is only recorded as an instance of equal / agreeing
//'         / matching drops (shrinks or crumbles) in both QtyDD and QtySS.
//'     2). All bi-rectional changes in Qd and Qs are construed to point out to swelling up of quantities [deltaQ+] or crumble downs
//'         [deltaQ-].

//' @param Qty_Dd
//' @param Qty_Ss
//'
//' @examples
//' TradedVolume( Qty_Dd , Qty_Ss)
//'
//' @return A list containing Settled trades and activity residuals.

# include <Rcpp.h>

# include <cmath>

using namespace Rcpp;

// [[Rcpp::export]]

Rcpp::List TradedVolume(Rcpp::NumericMatrix Qty_Dd,Rcpp::NumericMatrix Qty_Ss){

  int rowNum=Qty_Dd.nrow(),colNum=Qty_Dd.ncol();

  double deltaDd=0.0,deltaSs=0.0;

  // Declare 3 matrix objects for output

  NumericMatrix Settled(rowNum,colNum);
  NumericMatrix Dd_Surplus(rowNum,colNum);
  NumericMatrix Ss_Surplus(rowNum,colNum);


  for(int m=0;m<rowNum;m++){

    for(int n=1;n<colNum;n++) {

        deltaDd=Qty_Dd(m,n)-Qty_Dd(m,n-1);

        deltaSs=Qty_Ss(m,n)-Qty_Ss(m,n-1);

          if((deltaDd < 0.0 ) & (deltaSs < 0.0) & (deltaDd != deltaSs)){

              Settled(m,n)=round(std::min(std::abs(deltaDd),std::abs(deltaSs))*10000)/10000;

                    if(std::abs(deltaDd)>std::abs(deltaSs)){

                            //NB:: -ve signage maintained to capture volume utilization and surplus crumbling down.

                        Dd_Surplus(m,n)=round(-10000*(std::abs(deltaDd)-std::abs(deltaSs)))/10000;

                    }else{

                            Ss_Surplus(m,n)=round(-10000*(std::abs(deltaSs)-std::abs(deltaDd)))/10000;
                    }

          }


          if((deltaDd < 0.0) & (deltaSs > 0.0)){

                Ss_Surplus(m,n)=round(deltaSs*10000)/10000;
                Dd_Surplus(m,n)=round(deltaDd*10000)/10000;   // maintains -ve signage on deltaDd.
          }

          if((deltaDd > 0.0) & (deltaSs < 0.0)){

            Dd_Surplus(m,n)=round(deltaDd*10000)/10000;

            Ss_Surplus(m,n)=round(deltaSs*10000)/10000;  // captures -ve crumbling down of Qs and swelling up of Dd above.

          }


          if((deltaDd > 0.0) & (deltaSs > 0.0)){

              Dd_Surplus(m,n)=round(deltaDd*10000)/10000;

              Ss_Surplus(m,n)=round(deltaSs*10000)/10000;

          }
          /*Adding 4 extra conditions to cover the non-zero set of possible combinations
            of delta_Dd and delta_Ss.
          */

          if((deltaDd > 0.0) & (deltaSs == 0.0)){
                Dd_Surplus(m,n)=round(deltaDd*10000)/10000;
          }

          if((deltaDd == 0.0)& (deltaSs > 0.0)){
                Ss_Surplus(m,n)=round(deltaSs*10000)/10000;
          }

          if((deltaDd < 0.0) & (deltaSs == 0.0)){
                Dd_Surplus(m,n)=round(deltaDd*10000)/10000;
          }

          if((deltaDd == 0) & (deltaSs < 0.0)){

            Ss_Surplus(m,n)=round(deltaSs*10000)/10000;
          }


          if((deltaDd==deltaSs) & (deltaDd>0.0) &(deltaSs>0.0) ){

            Dd_Surplus(m,n)=round(deltaDd*10000)/10000;

            Ss_Surplus(m,n)=round(deltaSs*10000)/10000;

          }
// converse of the 1st IF condition ....

          if((deltaDd==deltaSs) & (deltaDd<0.0) &(deltaSs<0.0) ){  //No surpluses to record.

            //Dd_Surplus(m,n)=round(deltaDd*10000)/10000;

            //Ss_Surplus(m,n)=round(deltaSs*10000)/10000;

            Settled(m,n) = round(10000*std::abs(deltaDd))/10000;   // Added on 20-01-2020

          }

    } //n


  }//m

 return Rcpp::List::create(

                           Rcpp::Named("Settled_Trades")=Settled,
                           Rcpp::Named("Dd_Surplus")=Dd_Surplus,
                           Rcpp::Named("Ss_Surplus")=Ss_Surplus


                           );


}
