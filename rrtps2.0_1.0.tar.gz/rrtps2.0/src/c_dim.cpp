// ' This function is the equivalent of the dim() function in base R.

//'  It returns dimensions of the input matrix.

//'  @param inMatrix

//'  @examples
//'  c_dim( matrix A )

//'  @return a list that has ncol and nrow of in_Matrix.


#include<Rcpp.h>


using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::List c_dim(Rcpp::NumericMatrix in_Matrix){

int a= in_Matrix.nrow();

int b= in_Matrix.ncol();


return Rcpp::List::create(Named("N_ROW",a),
                          Named("N_COL",b)
                          );


/*return Rcpp::List::create(
                          (a),(b)
                          );
*/

}
