
// ' This function receives a numeric matrix of observations and helps to over-write zero value observations.
// ' Price value of zero is unexpected and odd.
// 'The function replaces such zero values with the last non-zero observation of the variable in question, row by row.
//'
//'  @param inaMatrix
//'
//'  @examples
//'  nonZero_for_Zero( inaMatrix  )

//'  @return A matrix with possible 0-values overwritten.


#include <Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericMatrix nonZero_for_Zero(Rcpp::NumericMatrix inaMatrix){

int nRow,nCol=0;

nRow=inaMatrix.nrow();

nCol = inaMatrix.ncol();

    double lastNonZero=0.0;

    for(int m=0; m<nRow;m++){

            lastNonZero=0.0;

        for(int n=0;n<nCol;n++){

                if(inaMatrix(m,n)!=0.0){

                    lastNonZero = inaMatrix(m,n);
                }

            if(inaMatrix(m,n)==0.0){

                inaMatrix(m,n) = lastNonZero;
            }

        }

    }

return inaMatrix;

}
