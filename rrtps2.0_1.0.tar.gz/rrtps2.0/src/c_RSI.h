#ifndef C_RSI_H_INCLUDED
#define C_RSI_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericVector c_RSI(Rcpp::NumericVector priceDelta , int n_periods);

#endif // C_RSI_H_INCLUDED
