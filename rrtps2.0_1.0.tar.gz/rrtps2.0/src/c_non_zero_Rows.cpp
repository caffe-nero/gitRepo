// 'This function receives a numeric matrix and returns row numbers that are not full of zeros.

//'  A sum by rows approach is applied.

//'  @param Target_Matrix

//'  @examples
//'  c_non_zero_Rows( xVecToSaddle , xCrossOver_Pts )

//'  @return positional integer vector of row numbers of Target_Matrix that don't contain zeros only.

#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::IntegerVector c_non_zero_Rows(Rcpp::NumericMatrix Target_Matrix){

int n_row=Target_Matrix.nrow();

NumericVector tempRng;

IntegerVector outputVec;


for(int i=0;i<n_row;i++){

    tempRng = Target_Matrix(i,_);

  if(std::accumulate(tempRng.begin(),tempRng.end(),0.0) !=0){

    outputVec.push_back(i);

  }
}

return outputVec;

}

