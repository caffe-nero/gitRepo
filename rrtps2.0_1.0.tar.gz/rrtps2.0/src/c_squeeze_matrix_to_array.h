#ifndef C_SQUEEZE_MATRIX_TO_ARRAY_H_INCLUDED
#define C_SQUEEZE_MATRIX_TO_ARRAY_H_INCLUDED

#include <Rcpp.h>

Rcpp::NumericMatrix c_squeeze_matrix_to_array( Rcpp::List in_List, Rcpp::IntegerVector Tpts);

#endif // C_SQUEEZE_MATRIX_TO_ARRAY_H_INCLUDED
