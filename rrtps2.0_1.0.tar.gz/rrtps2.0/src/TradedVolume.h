#ifndef TRADEDVOLUME_H_INCLUDED
#define TRADEDVOLUME_H_INCLUDED

#include<Rcpp.h>

Rcpp::List TradedVolume(Rcpp::NumericMatrix Qty_Dd,Rcpp::NumericMatrix Qty_Ss);

#endif // TRADEDVOLUME_H_INCLUDED
