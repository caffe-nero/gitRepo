#ifndef C_DIFF_H_INCLUDED
#define C_DIFF_H_INCLUDED

#include <Rcpp.h>

// function definition for c_diff function.

Rcpp::NumericVector c_diff(Rcpp::NumericVector vecIn);

#endif // C_DIFF_H_INCLUDED
