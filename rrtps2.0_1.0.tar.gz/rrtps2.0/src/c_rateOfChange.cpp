
// 'This function receives a numeric vector and returns rate of change between all 2 adjacent elements.

//'  It simply evaluates at all n:

//'  100 *[ ( X_n+1 - X_n ) / X_n ]

//'  @param inVector

//'  @examples
//'  c_rateOfChange( inVector )

//'  @return percent changes % between adjacent elements in inVector.

#include <Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericVector c_rateOfChange(Rcpp::NumericVector inVector){

    NumericVector outVector(inVector.size());

    outVector[0] = 0.0;

for(int i=1; i<inVector.size(); i++){

      if((Rcpp::traits::is_na<REALSXP>(inVector[i]/ inVector[i-1])) || (Rcpp::traits::is_infinite<REALSXP>( inVector[i]/ inVector[i-1]))){

        outVector[i] = 0.0;

      }else{

        double temp=0.0;

        temp = round(100000*(inVector[i] - inVector[i-1])/std::abs(inVector[i-1]))/100000;

        outVector[i] = 100*temp;

      }
}

return outVector;

}
