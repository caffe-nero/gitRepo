/*

This module helps to calculate the utilization / uptake of Demand and supply.

Algorithm utilizes residual_Dd and Residual_Ss outputs from the TradedVolume module...already in rrtps.

Input Surplus  :  (Residual_VD  , Residual _VS)

Input Quantity :   (Qty_Dd      ,  Qty_Ss     )

Bound          :    range (0,1)


*/

#include <Rcpp.h>

#include <numeric>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericMatrix utils (Rcpp::NumericMatrix surplus , Rcpp:: NumericMatrix quantity){

  NumericMatrix outMatrix(surplus.nrow() , surplus.ncol());

  if( (surplus.nrow() != quantity.nrow()) || (surplus.ncol() != quantity.ncol())   ){

    throw Rcpp ::exception("Error --> supply_matrix and quantity_matrix dimensions must match. If surplus_matrix columns are short by 1, add a leading zeros-column to the matrix . Exiting .. !!");

   } else{

// loop row-wise to get partial sums

for(int m = 0 ; m < surplus.nrow() ; m++){

   // recreate for every row .... starting afresh

   NumericVector temp_vec_surplus  = surplus(m , _);

   NumericVector temp_vec_quantity = quantity(m , _);

   NumericVector vec_surplus(temp_vec_surplus.size());

   NumericVector vec_quantity(temp_vec_quantity.size());

   std::partial_sum(temp_vec_surplus.begin(), temp_vec_surplus.end(),vec_surplus.begin());

   std::partial_sum(temp_vec_quantity.begin(), temp_vec_quantity.end(), vec_quantity.begin());

        for(int n = 0 ; n < vec_surplus.size() ; n++){

           if( (Rcpp::traits::is_nan<REALSXP>(vec_surplus[n] / vec_quantity[n])) || (Rcpp::traits::is_infinite<REALSXP>(vec_surplus[n] / vec_quantity[n])) ){

                outMatrix(m,n) = 0.0;

           }else{

             outMatrix(m,n) = 1- round(10000*vec_surplus[n] / vec_quantity[n])/10000;


           } //end IF


        } //forLoop


} //for-    Loop

   } //. if noThrow .........

return outMatrix;
}
