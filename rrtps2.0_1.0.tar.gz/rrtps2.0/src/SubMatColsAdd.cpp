
// ' This function receives a numeric matrix of observations and an integer vector representing time-slots.

//' Rows in the matrix represent different asset pairs under analysis.
//' The function returns a sum of deltas across 2 points defined by 2 (time-positional)adjacent elements of HrMarks.
//'  @param inMatrix
//'  @param HrMarks

//'  @examples
//'  MatColsAdd( inMatrix c(1,3,5,12)  )

//'  @return A matrix of sums of delta.

#include <Rcpp.h>
#include<cmath>
using namespace Rcpp;

// [[Rcpp::export]]
Rcpp::NumericMatrix MatColsAdd(Rcpp::NumericMatrix inMatrix,Rcpp::IntegerVector HrMarks) {


  int rowNum=inMatrix.nrow(),hrLen=HrMarks.size();

  NumericMatrix outMatrix(rowNum,hrLen-1);

 // IntegerVector span;

  double cellSum=0.0;


   //span=Range(HrMarks[0],HrMarks[1]);

   for(int l=1;l<hrLen;l++){//

     IntegerVector span=Range(HrMarks[l-1],HrMarks[l]);

     for(int m=0;m<rowNum;m++){

       cellSum=0.0;

        for(int k:span){

          cellSum+=inMatrix(m,k);

            //cellSum+=round(inMatrix(m,k)*1000.0)/1000.0;

        }//k

        outMatrix(m,l-1)=round(cellSum*100000.0)/100000.0;

     }//m



   }//l



    return outMatrix;

}//EOF
