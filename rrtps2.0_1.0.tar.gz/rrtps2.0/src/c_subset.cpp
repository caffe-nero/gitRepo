// ' This function replicated the subset function() in base R and returns a subset of a larger Matrix dimensioned by Row vectors and Column vectors.
// '
//'  @param InputMatrix
//'  @param Rows
//'  @param Columns

//'  @examples
//'  c_subset( InputMatrix , Rows , Columns )

//'  @return shorter matrix as dimensioned by provided row and column vectors..

# include<Rcpp.h>


using namespace Rcpp;

//[[Rcpp::export]]
Rcpp::NumericMatrix c_subset(Rcpp::NumericMatrix InputMatrix, Rcpp::IntegerVector Rows, Rcpp::IntegerVector Columns){


int rows_IM = InputMatrix.nrow();

int cols_IM = InputMatrix.ncol();

NumericMatrix outputMatrix( Rows.size(),Columns.size()  );

bool cond1=false;

if( (Rows.size()<=rows_IM) && ( Columns.size() <=cols_IM ) && (Rows[Rows.size()-1]<=rows_IM) && (Columns[ Columns.size()-1] <= cols_IM )      ){

        cond1=true;
}


if(cond1 != true){

    throw Rcpp::exception("crappy dimensions requested !!");

}else{



//if( (Rows.size()<=rows_IM) && ( Columns.size() <=cols_IM      )  ){

 int n_Rows=Rows.size();
 int n_Cols=Columns.size();

  for(int i=0;i<n_Rows;i++){

    for(int j=0; j<n_Cols;j++){

        outputMatrix(i,j) = InputMatrix( Rows[i],Columns[j]);

    }


  }

}
 return outputMatrix;
}
