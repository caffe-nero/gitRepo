#ifndef C_WHICH_XINY_H_INCLUDED
#define C_WHICH_XINY_H_INCLUDED

#include <Rcpp.h>

Rcpp::IntegerVector c_Which_XinY(Rcpp::IntegerVector VecX,Rcpp::IntegerVector VecY);

#endif // C_WHICH_XINY_H_INCLUDED
