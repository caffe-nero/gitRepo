#ifndef C_MINIMA_COUNT_H_INCLUDED
#define C_MINIMA_COUNT_H_INCLUDED

#include<Rcpp.h>

Rcpp::IntegerVector c_minima_count(Rcpp::NumericVector yVecToSaddle, Rcpp::IntegerVector yCrossOver_Pts);

#endif // C_MINIMA_COUNT_H_INCLUDED
