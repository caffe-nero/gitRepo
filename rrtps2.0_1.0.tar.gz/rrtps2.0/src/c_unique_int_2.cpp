// ' This function does NOT replicate the unique function() in base R but for integer vectors.
// ' It is a correction on the earlier c_unique_int () that has a bug::
/*
        BUG ALERT!

    CULPRIT ::      if(in_Vector[i] != outVector[outVector.size()-1]){}

    This statement misses out where inVector[i] ==0. Note..the  2nd part of the statement also evaluates to 0, as this is the
    default value of an unassigned vector.

    Correction:!
    =============
    Adding statement below before statement above is evaluated:

    if((in_Vector[i]==0) &&(outVector[outVector.size()-1]==0) ){


 */


//'  @param in_Vector

//'  @examples
//'  c_unique_int(in_Vector)

//'  @return unique elements in in_Vector.

#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::IntegerVector c_unique_int_2(Rcpp::IntegerVector in_Vector){

IntegerVector outVector;

for(int i=0; i < in_Vector.size() ; i++){

    if((in_Vector[i]==0) &&(outVector[outVector.size()-1]==0) ){
        outVector.push_back(in_Vector[i]);
    }

    if(in_Vector[i] != outVector[outVector.size()-1]){

        outVector.push_back(in_Vector[i]);
    }
}
return outVector;

}
