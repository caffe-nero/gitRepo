
// 'This function receives a list of matrices and it returns one (shorter) matrix, that shows j columns provided by Tps arg.

//' The matrices in the list must be of the same dimension.

//'  @param inList
//,  @param Tpts

//'  @examples
//'  c_squeeze_matrix_to_array( inList , Tpts )

//'  @return simplified matrix with no blanks; Almost a complete_cases.
#include <Rcpp.h>

#include "c_subset.h"

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericMatrix c_squeeze_matrix_to_array( Rcpp::List in_List, Rcpp::IntegerVector Tpts){

NumericMatrix outMatrix( Tpts.size(),in_List.size() );

int numList=in_List.size();

for(int i=0 ; i < numList ; i++){

 int n_row = Rcpp::as<Rcpp::NumericMatrix>(in_List[i]).nrow();
 int n_col = Rcpp::as<Rcpp::NumericMatrix>(in_List[i]).ncol();

 NumericMatrix currMatrix(n_row,n_col);

 currMatrix=Rcpp::as<Rcpp::NumericMatrix>(in_List[i]);

 NumericMatrix t_temp_Matrix(currMatrix.ncol(),currMatrix.nrow());

 t_temp_Matrix=transpose(currMatrix);

 IntegerVector finalRows = Tpts;

 IntegerVector finalCols = Range(0 , t_temp_Matrix.ncol()-1);

 NumericMatrix tempMatrix(finalRows.size(),finalCols.size());

 tempMatrix = c_subset(t_temp_Matrix,finalRows,finalCols);

    for(int m=0; m < Tpts.size();m++){

        NumericVector TempCol = tempMatrix(m,_);

        double tempSum = std::accumulate(TempCol.begin(),TempCol.end(),0.0);

        outMatrix(m,i) = round(1000*tempSum)/1000;
    }

}

return outMatrix;

}
