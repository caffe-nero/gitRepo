#ifndef C_CROSSOVERS_H_INCLUDED
#define C_CROSSOVERS_H_INCLUDED

#include <Rcpp.h>

Rcpp::IntegerVector c_crossOvers(Rcpp::NumericVector vec_A, Rcpp::NumericVector vec_B);

#endif // C_CROSSOVERS_H_INCLUDED
