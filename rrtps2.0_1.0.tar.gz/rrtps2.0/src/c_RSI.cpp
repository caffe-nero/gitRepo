

// 'This function receives a numeric vector of prices and returns relative strength index for a time-series of price data.

//'  @param priceDelta

//'  @param n_periods

//'  @examples
//'  c_RSI( priceDelta , n_periods )

//'  @RSI variables given price time_series and order of RSI.

#include<cmath>
#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericVector c_RSI(Rcpp::NumericVector priceDelta , int n_periods){

// step 1: separate +VE and -VE price changes in 2 vectors

NumericVector vecPos;

NumericVector vecNegs;

NumericVector RS_pos;

NumericVector RS_negs;


for(int i=0 ; i < priceDelta.size(); i++){

    if(priceDelta[i]==0){

        vecPos.push_back(0.0);

        vecNegs.push_back(0.0);

        }

     if(priceDelta[i] < 0){

        vecPos.push_back(0.0);

        vecNegs.push_back( std::abs(priceDelta[i]) );

     }

     if(priceDelta[i]>0){

        vecPos.push_back(priceDelta[i]);

        vecNegs.push_back(0.0);
     }

}

NumericVector Avg_Gain;

NumericVector Avg_Loss;

NumericVector RSI;

//populating 0 for the first [n_period-1] indices.

for(int i=0 ; i < (n_periods-1) ; i++){

   Avg_Gain.push_back(0.0);

   Avg_Loss.push_back(0.0);

   RSI.push_back(0.0);

}

//populating at INDEX n_periods

double pos_sums=0.0;

double neg_sums=0.0;


for(int i=0; i < n_periods ; i++){

    pos_sums+=vecPos[i];

    neg_sums+=vecNegs[i];
}

//at index n_periods - 1:
Avg_Gain.push_back(pos_sums/n_periods);

Avg_Loss.push_back(neg_sums/n_periods);

for(int i = n_periods ; i < priceDelta.size() ;  i++  ){

  double pos_tempsum =  0.0;

  double neg_tempsum =  0.0;

  //see :  https://en.wikipedia.org/wiki/Relative_strength_index

  pos_tempsum = round(1000*(Avg_Gain[i-1] * (i-1) + vecPos[i]))/(1000*i);

  neg_tempsum = round(1000*(Avg_Loss[i-1] * (i-1) + vecNegs[i]))/(1000*i);

//populating indices after n_periods-1

  Avg_Gain.push_back(pos_tempsum);

  Avg_Loss.push_back(neg_tempsum);

}

//writing to RSI

double RS=0.0;

for(int i = n_periods-1 ; i < priceDelta.size() ; i++){

 if (  (Rcpp::traits::is_nan<REALSXP>(Avg_Gain[i]/Avg_Loss[i]) ) ||  ( Rcpp::traits::is_infinite<REALSXP>(Avg_Gain[i]/Avg_Loss[i]) )   ){

   RS = 0.0;


 }else{

 RS = Avg_Gain[i]/Avg_Loss[i];

 }

 RSI.push_back(  100-(100/(1+RS))  );


}

    return RSI;
}
