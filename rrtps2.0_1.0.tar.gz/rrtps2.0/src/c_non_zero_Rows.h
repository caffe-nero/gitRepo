#ifndef C_NON_ZERO_ROWS_H_INCLUDED
#define C_NON_ZERO_ROWS_H_INCLUDED

#include<Rcpp.h>

Rcpp::IntegerVector c_non_zero_Rows(Rcpp::NumericMatrix Target_Matrix);

#endif // C_NON_ZERO_ROWS_H_INCLUDED
