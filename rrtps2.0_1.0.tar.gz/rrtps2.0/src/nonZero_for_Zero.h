#ifndef NONZERO_FOR_ZERO_H_INCLUDED
#define NONZERO_FOR_ZERO_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericMatrix nonZero_for_Zero(Rcpp::NumericMatrix inaMatrix);

#endif // NONZERO_FOR_ZERO_H_INCLUDED
