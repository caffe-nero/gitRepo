#ifndef C_NON_ZERO_COLS_H_INCLUDED
#define C_NON_ZERO_COLS_H_INCLUDED

#include <Rcpp.h>

Rcpp::IntegerVector c_non_zero_Cols(Rcpp::NumericMatrix TargetMatrix);

#endif // C_NON_ZERO_COLS_H_INCLUDED
