#ifndef C_DIM_H_INCLUDED
#define C_DIM_H_INCLUDED

#include<Rcpp.h>

Rcpp::List c_dim(Rcpp::NumericMatrix in_Matrix);

#endif // C_DIM_H_INCLUDED
