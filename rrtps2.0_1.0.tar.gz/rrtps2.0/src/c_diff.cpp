// ' This function is the equivalent of the diff() function in base R.

//'  It returns difference between adjacent numeric elements in a vector.

//'  @param vecIn

//'  @examples
//'  c_diff( vector_of_prices )

//'  @return numeric differences vector.


#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]


NumericVector c_diff(NumericVector vecIn){

  int vSize=vecIn.size();

  int xSize=vSize-1;

  NumericVector retVec(xSize);


/*
    for(int k=0;k<xSize;k++){

      retVec[k]=vecIn[k+1]-vecIn[k];
    }

*/


for(int k=1;k<vSize;k++){  //previously xSize

    retVec[k-1]=vecIn[k]-vecIn[k-1];
}



  return retVec;
}
