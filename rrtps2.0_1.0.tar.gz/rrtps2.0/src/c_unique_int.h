#ifndef C_UNIQUE_INT_H_INCLUDED
#define C_UNIQUE_INT_H_INCLUDED

#include<Rcpp.h>

Rcpp::IntegerVector c_unique_int(Rcpp::IntegerVector in_Vector);

#endif // C_UNIQUE_INT_H_INCLUDED
