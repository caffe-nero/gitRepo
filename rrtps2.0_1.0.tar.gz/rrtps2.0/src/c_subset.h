#ifndef C_SUBSET_H_INCLUDED
#define C_SUBSET_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericMatrix c_subset(Rcpp::NumericMatrix InputMatrix, Rcpp::IntegerVector Rows, Rcpp::IntegerVector Columns);

#endif // C_SUBSET_H_INCLUDED
