#ifndef C_SUBSET_H_INCLUDED
#define C_SUBSET_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericMatrix OIR(Rcpp::NumericMatrix Demand, Rcpp::NumericMatrix Supply);

#endif // C_SUBSET_H_INCLUDED
