
// 'This function receives a numeric matrix and returns column numbers that are not full of zeros.

//'  A sum by column approach is applied.

//'  @param TargetMatrix

//'  @examples
//'  c_non_zero_Cols( TargetMatrix)

//'  @return positional integer vector of column numbers of TargetMatrix that don't contain zeros only.




#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::IntegerVector c_non_zero_Cols(Rcpp::NumericMatrix TargetMatrix){

int n_col=TargetMatrix.ncol();

IntegerVector outVector;

for(int i=0; i< n_col; i++){

    NumericVector temp_Rng=TargetMatrix(_,i);

    if(std::accumulate (temp_Rng.begin(),temp_Rng.end(),0.0) !=0){

       outVector.push_back(i);
    }


}



return outVector;

}
