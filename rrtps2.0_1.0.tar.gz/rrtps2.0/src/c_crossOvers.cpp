// ' Function takes in cumulative vol_D and cumulative vol_S

//'  It then determines where the two SERIE cross over.

//'  @param vec_A
// ' @param vec_B

//'  @examples
//'  c_crossOvers( csum_Vol_D , csum_Vol_S )

//'  @return integer vector showing cross-over time-steps.

#include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]

IntegerVector c_crossOvers(NumericVector vec_A, NumericVector vec_B){

    int Vsize=vec_A.size();

    IntegerVector Crosses(Vsize);

    //IntegerVector CrossPoints(Vsize);

    IntegerVector CrossPoints(Vsize-1);

    IntegerVector nonBlanks;

    for(int k=0; k<Vsize; k++){

        if( vec_A[k] > vec_B[k] ){

          Crosses[k] = 1;

        }/*else{

        Crosses[k]=0;

        }*/

    }

/*
   for (int j=0 ; j<Vsize ; j++){


     if( Crosses[j] !=  Crosses[j+1]    ){

       CrossPoints[j+1]=1; //coincides with crossover points plotted

     }

   }

   */

   for(int j=1;j<=Vsize;j++){

    if(Crosses[j-1] != Crosses[j])

        CrossPoints[j-1]=1; //Corrected on 01-01-2020

          // BUG REPORT : CrossPoints[j]=1; Crashes at CrossPoints[j] when j == Vsize  !
   }

for(int n=0;n<CrossPoints.size();n++){

    if(CrossPoints[n]==1){

        nonBlanks.push_back(n+1); // was n : 01-01-2020. Inserting value n+1 captures the 1st instance when serie cross. ( After fact )
    }

}

//  }//endIF


  //return CrossPoints;

  return nonBlanks;

}
