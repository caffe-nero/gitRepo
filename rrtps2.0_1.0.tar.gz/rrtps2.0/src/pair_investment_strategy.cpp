/*

script analyzes future price inputs and determines modest entry and reversal points, alongside possible performance.

Aims at classifying a price series as either :

    1). OutrightLong   OL:
        Where Y(0) == min(price series)
    2). OutrightShort: OS:
        Where Y(0) == max(price series)
    3). ShortLong      SL:
        Where { Y(0) != max(price series) && Y(0) != min(price series) && ( Y(i) < Y(0) ) && ( Y(j) > Y(i)) }  # Y(j) : Max  #Y(i) : Min
    4). LongShort      LS:
        Where { Y(0) != max(price series) && Y(0) != min(price series) && ( Y(i) > Y(0) ) && ( Y(j) < Y(i)) }

  .... and also shows returns from the price series classification.
*/
#include <Rcpp.h>
#include <cmath>
#include "c_rateOfChange.h"
#include "dbl_Which_XinY.h"
#include "c_unique_int_2.h"
#include <sstream>
#include <string>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::DataFrame pair_invt_strategy(Rcpp::NumericVector PriceSeries, Rcpp::CharacterVector Tstamps ){

std::string Market;

std::string Narration;

int inSz = PriceSeries.size();

double Y_o = PriceSeries[0];

int min_time =0;
double min_price = Y_o;

int max_time = 0;
double max_price = Y_o;

double non_broker_perf = 0.0;
double broker_perf = 0.0;
double total_perf = 0.0;

//============ minimum and maximum price. NB: std::min() and std::max () take 2 doubles as inputs !
for(int i = 1 ; i < inSz; i++){

    if((PriceSeries[i] > PriceSeries[i-1]) && ( PriceSeries[i] > max_price)){
       max_price = PriceSeries[i];
    }

    if((PriceSeries[i] < PriceSeries[i-1]) && ( PriceSeries[i] < min_price)){
       min_price = PriceSeries[i];
    }
}
//=========================================

NumericVector vec_min(1);
vec_min[0] = min_price;
IntegerVector temp_min = c_unique_int_2(dbl_Which_XinY(PriceSeries,vec_min));

NumericVector vec_max(1);
vec_max[0] =  max_price;
IntegerVector temp_max = c_unique_int_2(dbl_Which_XinY(PriceSeries,vec_max));

min_time = temp_min[0];
max_time = temp_max[0];

NumericVector Two_Price(2);
NumericVector Three_Price(3);


if(PriceSeries[0] == max_price){
  Market = "OutrightShort";
  non_broker_perf = 0.0;
  Two_Price[0] = Y_o;
  Two_Price[1] = min_price;
  NumericVector temp_broker_perf = c_rateOfChange(Two_Price);
  broker_perf = std::abs(temp_broker_perf[temp_broker_perf.size()-1]);
  total_perf = non_broker_perf + broker_perf;
  std::string test_1 = "SHORT at ";
  std::ostringstream test_1_os;
  test_1_os << Y_o;
  std::string test_2 = test_1_os.str();
  std::string test_2a = " EXIT at ";
  std::ostringstream test_2_os;
  test_2_os << min_price;
  std::string test_2b = test_2_os.str();
 // std::string test_3 = " gain ";
//std::ostringstream test_3_os;
//test_3_os << total_perf;
//std::string test_3a = test_3_os.str();
//std::string test_4 = " %.";
  Narration = test_1 + test_2 + test_2a +test_2b;// + test_3 + test_3a + test_4;

}

if(PriceSeries[0] == min_price){
Market = "OutrightLong";
Two_Price[0] = min_price;
Two_Price[1] = max_price;
NumericVector temp_broker_perf = c_rateOfChange(Two_Price);
non_broker_perf = std::abs(temp_broker_perf[temp_broker_perf.size()-1]);
broker_perf = 0.0;
total_perf = non_broker_perf + broker_perf;

std::string test_1 = "BUY at ";
std::ostringstream test_1_os;
test_1_os << Y_o;
std::string test_2 = test_1_os.str();
std::string test_2a = " SELL at ";
std::ostringstream test_2_os;
test_2_os << max_price;
std::string test_2b = test_2_os.str();
//std::string test_3 = " gain ";
//std::ostringstream test_3_os;
//test_3_os << total_perf;
//std::string test_3a = test_3_os.str();
//std::string test_4 = " %.";
Narration = test_1 + test_2 + test_2a +test_2b;// + test_3 + test_3a + test_4;
}

if( (PriceSeries[0] != min_price) && (PriceSeries[0] !=max_price) && (min_time < max_time)   ){
Market = "ShortLong";
Three_Price[0] = Y_o;
Three_Price[1] = min_price;
Three_Price[2] = max_price;
NumericVector temp_broker_perf = c_rateOfChange(Three_Price);
broker_perf = std::abs(temp_broker_perf[temp_broker_perf.size()-2]);//:    std::abs(temp_broker_perf[1]);
non_broker_perf = std::abs(temp_broker_perf[temp_broker_perf.size()-1]);//std::abs(temp_broker_perf[2]);
total_perf = non_broker_perf + broker_perf;

std::string broker_sign ="SHORT at ";
std::ostringstream os_shortPrice;
os_shortPrice << Y_o;
std::string shortPrice = os_shortPrice.str();
std::string close_broker_sign = ".Close & goLONG at ";
std::ostringstream os_min_price;
os_min_price << min_price;
std::string close_min_price = os_min_price.str();
std::string close_non_broker_sign = " .EXIT at ";
std::ostringstream os_max_price;
os_max_price << max_price;
std::string close_max_price = os_max_price.str();
//std::string gain =" gain ";
//std::ostringstream gainPc;
//gainPc<<total_perf;
//std::string exit_gainPc = gainPc.str();
//std::string percent =" %";

Narration = broker_sign + shortPrice + close_broker_sign + close_min_price+close_non_broker_sign+close_max_price;// + gain +exit_gainPc +percent;

}

if( (PriceSeries[0] != min_price) && (PriceSeries[0] !=max_price) && (min_time > max_time)   ){

Market = "LongShort";
Three_Price[0] = Y_o;
Three_Price[1] = max_price;
Three_Price[2] = min_price;

NumericVector temp_broker_perf = c_rateOfChange(Three_Price);
non_broker_perf = std::abs(temp_broker_perf[temp_broker_perf.size()-2]);//std::abs(temp_broker_perf[1]);
broker_perf = std::abs(temp_broker_perf[temp_broker_perf.size()-1]);//std::abs(temp_broker_perf[2]);
total_perf = non_broker_perf + broker_perf;

std::string non_broker_sign ="BUY at ";
std::ostringstream os_LongPrice;
os_LongPrice << Y_o;
std::string LongPrice = os_LongPrice.str();

std::string close_non_broker_sign = ".Close & SHORT at ";
std::ostringstream os_max_price;
os_max_price << max_price;
std::string close_max_price = os_max_price.str();
std::string close_broker_sign = ". EXIT at ";

std::ostringstream os_min_price;
os_min_price << min_price;
std::string close_min_price = os_min_price.str();

//std::string gain =" gain ";
//std::ostringstream gainPc;
//gainPc<<total_perf;
//std::string exit_gainPc = gainPc.str();
//std::string percent =" %";

Narration = non_broker_sign+LongPrice+close_non_broker_sign+close_max_price+close_broker_sign+close_min_price;//+gain+exit_gainPc+percent;

}

std::string min_tseries = Rcpp::as<std::string>(Tstamps[min_time]);
std::string max_tseries = Rcpp::as<std::string>(Tstamps[max_time]);

Rcpp::List outList = Rcpp::List::create(Market,Y_o,min_tseries,min_price,max_tseries,max_price,non_broker_perf,broker_perf,total_perf,Narration);

Rcpp::CharacterVector NameVec(10);

NameVec[0] = "strategy";
NameVec[1] = "currPRC";
NameVec[2] = "min_time";
NameVec[3] = "min_price";
NameVec[4] = "max_time";
NameVec[5] = "max_price";
NameVec[6] = "vanilla_pc";
NameVec[7] = "exotic_pc";
NameVec[8] = "hybrid_pc";
NameVec[9] = "narration";

outList.attr("names") = NameVec;

Rcpp::DataFrame outDF(outList);

return outDF;

}



