#ifndef HOLTS_CV_PREDICTOR_H_INCLUDED
#define HOLTS_CV_PREDICTOR_H_INCLUDED

#include<Rcpp.h>

Rcpp::List Holts_CV_predictor(Rcpp::NumericMatrix Features_matrix, Rcpp::NumericVector Alphas,Rcpp::NumericVector Betas, int Test);

#endif // HOLTS_CV_PREDICTOR_H_INCLUDED
