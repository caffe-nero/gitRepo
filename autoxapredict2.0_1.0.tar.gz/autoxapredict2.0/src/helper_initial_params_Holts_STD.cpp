/*
Designed to work with 'Holts_STD_predictor(Features_matrix,int iter_k_period,const double L_t, const double B_t)'.

It is a smart tweak to fast estimate INITIAL optimum values of alpha and beta for std_Holts smoothing model.

Helper function to Holts_STD_predictor().
*/

#include <Rcpp.h>
#include "RMSE.h"
#include <cmath>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::List helper_initial_params_Holts_STD(Rcpp::NumericVector X){

NumericVector Alphas = NumericVector::create(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9);

NumericVector Betas  = NumericVector::create(0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9); // 0.1 tested below in maiden run as dummyBeta

int inSz = X.size();

NumericVector Level (inSz);

NumericVector Growth (inSz);

NumericVector X_hat(inSz);

//setting up preliminary values:

Level[0] = X[1];

Growth[0] = X[1]-X[0];

X_hat[0]  = X[0];

//populating vectors
double TestLoss  = 999.99;
double bestAlpha = 0.0;
double bestBeta  = 0.0;
NumericVector opti_XHat;

//approximation of optimum alpha then beta given optimum alpha:

double dummyBeta = 0.1;

for (auto y : Alphas){

    for(int m = 1 ; m < X.size() ; m++){

        Level[m] = y*X[m] + (1-y)*(Level[m-1] + Growth[m-1]);

        Growth[m] = dummyBeta*(Level[m] - Level[m-1]) - (1-dummyBeta)*Growth(m-1);

        X_hat[m] = Level[m] + Growth[m];

    }

    double curRMSE = RMSE(X,X_hat);

    if (curRMSE < TestLoss){
        TestLoss = curRMSE;
        bestAlpha = y;

    }

}// range- based loop alpha


for( auto z : Betas){

    for(int n=1 ; n < X.size() ; n++){

        Level[n] = bestAlpha*X[n] + (1-bestAlpha)*(Level[n-1] + Growth[n-1]);

        Growth[n] = z*(Level[n] - Level[n-1]) - (1.0-z)*Growth(n-1);

        X_hat[n] = Level[n] + Growth[n];

    }


    double curRMSE =RMSE(X,X_hat);

    if(curRMSE < TestLoss){
      bestBeta = z;
      opti_XHat = X_hat;

    }

}

return Rcpp::List::create(
                          Named("L_t",Level[Level.size()-1]),
                          Named("b_t",Growth[Growth.size()-1]),
                          Named("alpha",bestAlpha),
                          Named("beta",bestBeta),
                          Named("fitted", opti_XHat)

                          );

}
