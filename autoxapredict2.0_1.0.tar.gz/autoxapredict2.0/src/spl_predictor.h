#ifndef SPL_PREDICTOR_H_INCLUDED
#define SPL_PREDICTOR_H_INCLUDED

#include <Rcpp.h>

Rcpp::List spl_predictor(Rcpp::NumericMatrix FeatureMatrix, Rcpp::NumericVector L_percentiles,Rcpp::NumericVector U_percentiles,std::string MEAN_or_DRAW);


#endif // SPL_PREDICTOR_H_INCLUDED
