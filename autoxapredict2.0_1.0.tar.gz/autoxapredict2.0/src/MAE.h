#ifndef MAE_H_INCLUDED
#define MAE_H_INCLUDED

#include <Rcpp.h>

double MAE(Rcpp::NumericVector actual, Rcpp::NumericVector predicted);


#endif // MAE_H_INCLUDED
