/*
timevec_split takes in spandata_mins (parent data in minutes) and candle_mins (span of candle).

Function splits spandata_mins into candles_bars, each candle_mins long.

Output is a list of 2 vectors; CandleBar_starts and CandleBar_ends.

*/

#include<Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]
Rcpp::NumericMatrix Candle_Intervals(int spandata_mins, int candle_size_mins){

if((spandata_mins <1) ||(candle_size_mins <1)){

    throw Rcpp::exception("Inputs must be >= 1!");
}


if(candle_size_mins > spandata_mins){
    throw Rcpp::exception("Candle_Length must be LESS than spandata_mins inputed!");
}



if(spandata_mins % candle_size_mins !=0){

    spandata_mins -= spandata_mins % candle_size_mins;
}

NumericVector spanList(spandata_mins);

for(int i = 0; i<spandata_mins; i++){
    spanList[i] = i;
}

NumericVector CandleBarStarts;
NumericVector CandleBarEnds;

int folds = spanList.size()/candle_size_mins;

NumericMatrix outMatrix(2,folds);

for(int k = 0 ; k < folds; k++){

  int fold_start = k*candle_size_mins;

  CandleBarStarts.push_back(fold_start);

  CandleBarEnds.push_back(fold_start + candle_size_mins - 1);

}

outMatrix(0,_) = CandleBarStarts;

outMatrix(1,_) = CandleBarEnds;

return outMatrix;
}
