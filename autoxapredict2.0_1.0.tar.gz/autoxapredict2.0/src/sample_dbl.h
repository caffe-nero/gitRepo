#ifndef SAMPLE_DBL_H_INCLUDED
#define SAMPLE_DBL_H_INCLUDED

#include <Rcpp.h>

Rcpp::NumericVector sample_with_rpl(Rcpp::NumericVector x, int sz, bool rep = true, Rcpp::sugar::probs_t p = R_NilValue);

#endif // SAMPLE_DBL_H_INCLUDED
