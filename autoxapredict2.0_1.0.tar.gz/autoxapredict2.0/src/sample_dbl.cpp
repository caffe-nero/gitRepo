// https://stackoverflow.com/questions/46230526/generating-a-random-sample-of-integers-with-unequal-probability-in-rcpp

// https://github.com/RcppCore/Rcpp/blob/e81493bd988a5ee93e5a35458662dd2582de1c5d/inst/unitTests/cpp/sugar.cpp#L1148-L1190

// simple sampler built on Rcpp::sugar.

# include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]

Rcpp::NumericVector sample_with_rpl(Rcpp::NumericVector x, int sz, bool rep = true, Rcpp::sugar::probs_t p = R_NilValue)
{
    return Rcpp::sample(x, sz, rep, p);
}
