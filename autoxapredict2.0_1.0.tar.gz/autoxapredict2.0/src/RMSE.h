#ifndef RMSE_H_INCLUDED
#define RMSE_H_INCLUDED

#include <Rcpp.h>


double RMSE(Rcpp::NumericVector yHat, Rcpp::NumericVector y);

#endif // RMSE_H_INCLUDED
