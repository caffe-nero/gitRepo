/* Holts smoothing with control parameters for level(alpha) and trend(beta)...unlike the SMA smoothing in versions.

   The variation is a suggested tweak by Xapiens.
   This implementation is varied from the standard Holt's method by :

  1). introducing dynamic Alpha and Beta for each run. The data to estimate this follows implementation for SMA; every nTh run
      uses (n-1) input data rows and appends a last estimate of nTh row data.

  2). the standard Holt's estimation of Y_hat (next 1-step) is L(t) + h(Bt) where h is the prediction period. Here, this is
      fixed at 1.0 and not the period of forecast ( say 4 periods, 10 periods from now ). The implementation here is a recursive
      run incremented by one, such that a prediction period of 4 is implemented as 4 loops of h = 1 for each period.

*/

#include <Rcpp.h>
#include "MAE.h"
#include "RMSE.h"
#include "helper_iterate_params_Holts_CV.h"
#include <cmath>
#include "mean_errors_bootstrapper.h"

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::List Holts_CV_predictor(Rcpp::NumericMatrix Features_matrix, Rcpp::NumericVector Alphas,Rcpp::NumericVector Betas, int Test){

int cols = Features_matrix.ncol();
int rows = Features_matrix.nrow();

//Aggregate collectors:
NumericVector loss_fn_value    (cols); //# size:= number of features.
NumericVector optimum_Alpha (cols); //# size:= number of features.
NumericVector optimum_Beta   (cols);
NumericVector std_devs         (cols);

NumericMatrix residual_errors (rows , cols); // # squared errors
NumericMatrix feature_means   (rows , cols);
NumericMatrix unsquared_errors (rows,cols);

NumericVector suspended_errors;

std::string LossFunction;

if((Test < 0) || (Test >1)){

    throw Rcpp::exception(" 'Test' only accepts a value of 0 for MAE or 1 for RMSE. Function exited.");

}else{

if(Test == 0){

    LossFunction = "MAE";

}else{

LossFunction = "RMSE";

}
//  Looping across features
//============================
for(int n = 0 ; n < cols ; n++){

// read in  feature values
NumericVector y_values = Features_matrix(_ , n);

// declare holders of optimum parameters for feature.
    double lossTemp = 999.99;
    double bestAlpha = 0.0;
    double bestBeta = 0.0;
    NumericVector squared_errors;
    NumericVector non_squared_errors;
    NumericVector Trend;
    double std_dev = 0.0;

   // select optimum Alpha and record key optimum measurements:
    for(auto x : Alphas){
        for(auto y : Betas){

          NumericVector yHat_values = helper_iterator_params_Holts_CV(y_values,x,y);

           double lossValue=0.0;  //resets to 0 for each alpha.

                if(LossFunction=="MAE"){
                    lossValue = MAE(y_values,yHat_values);
                }
                if(LossFunction =="RMSE"){
                    lossValue = RMSE(y_values,yHat_values);
                }


    if(lossValue < lossTemp){ // less loss_function_value at MA_order[x].
        lossTemp = lossValue;
        bestAlpha = x;
        bestBeta  = y;

        non_squared_errors = yHat_values - y_values;
        int kk = squared_errors.size();

        squared_errors = non_squared_errors *non_squared_errors;
        std_dev = sqrt(std::accumulate(squared_errors.begin(), squared_errors.end(),0.0)/kk);
        Trend = yHat_values;
    } // end IF

    } // range based loop
    } //// range based loop

//  Global Containers below were created upstream. Now populating per feature...:

loss_fn_value[n] = lossTemp;

optimum_Alpha[n] = bestAlpha;

optimum_Beta[n] = bestBeta;

residual_errors(_,n) = squared_errors;

unsquared_errors(_,n) = non_squared_errors;

feature_means(_,n) = Trend;

std_devs[n] = std_dev;

} // n-feature

}// validation_if for testing input flags for MAE or MEAN.

//  Bootstrapping to estimate re-sampled mean of errors per feature.
// ====================================================================


//NumericMatrix adj_means(rows,cols);
NumericVector resampled_error_mu (cols);

for(int j = 0 ; j < cols ; j++){

 double error_mu = means_errors_bootstrap(unsquared_errors(_,j),ceil(unsquared_errors(_,j).size()/5),250,0.8)[2];
 suspended_errors.push_back(error_mu);

}

NumericMatrix predicted(rows+1,cols);

// Irresponsible duplication  of matrix. Clone is better....only that the dimensions have to change here.

// Remember the last row of a matrix that has n_rows is indexed n_rows-1.

for(int hz = 0 ;hz < rows; hz++){
  predicted(hz,_) = Features_matrix(hz,_);
}

predicted(rows,_) = feature_means(rows-1,_);

return Rcpp::List::create(

                   Named("Std_Dev"           ,std_devs),
                   Named("Unsquared_errors"  ,unsquared_errors),
                   Named("Past_N_Future"     , predicted),
                   Named("Suspended_errors"   ,suspended_errors)

                    );


} // function
