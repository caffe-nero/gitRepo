//Calculates Median value of a numeric series.

#include <Rcpp.h>

using namespace Rcpp;

//[[Rcpp::export]]

double c_median(Rcpp::NumericVector inVector){

std::sort(inVector.begin(),inVector.end());

int vecsize = inVector.size();

int split_place=0;

double Ans=0.0;

if(vecsize % 2 !=0){

    split_place = (vecsize-1)/2;

    Ans = inVector[split_place];

}else{

split_place = vecsize/2;

Ans = (inVector[split_place-1]+inVector[split_place])/2.0;

}

return Ans;

}
