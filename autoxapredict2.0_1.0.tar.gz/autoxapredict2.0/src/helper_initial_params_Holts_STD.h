#ifndef HELPER_INITIAL_PARAMS_HOLTS_STD_H_INCLUDED
#define HELPER_INITIAL_PARAMS_HOLTS_STD_H_INCLUDED

#include <Rcpp.h>

Rcpp::List helper_initial_params_Holts_STD(Rcpp::NumericVector X);

#endif // HELPER_INITIAL_PARAMS_HOLTS_STD_H_INCLUDED
