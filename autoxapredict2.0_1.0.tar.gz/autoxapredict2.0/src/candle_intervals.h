#ifndef CANDLE_INTERVALS_H_INCLUDED
#define CANDLE_INTERVALS_H_INCLUDED

#include <Rcpp.h>

Rcpp::NumericMatrix Candle_Intervals(int spandata_mins, int candle_size_mins);

#endif // CANDLE_INTERVALS_H_INCLUDED
