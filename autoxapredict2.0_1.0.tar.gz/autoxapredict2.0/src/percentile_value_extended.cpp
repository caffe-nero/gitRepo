#include<Rcpp.h>
#include<cmath>
#include "sample_dbl.h"

using namespace Rcpp;

//[[Rcpp::export]]

int percentile_value_extended(Rcpp::NumericVector inVector,double percentile,int BootCycles){

if(BootCycles<1){throw Rcpp::exception("BootCycles must be >1 !!");}

if(percentile<0.01){percentile = 0.01;}
if(percentile>0.99){percentile = 0.99;}

int Sz = inVector.size();

NumericVector temp_samples(BootCycles);

double sample_mu = std::accumulate(inVector.begin(),inVector.end(),0.0)/Sz;

//sample size

int SampleSz = ceil(Sz/(std::log(Sz)*std::log10(Sz)));

for(int i=0 ; i<BootCycles;i++){
 NumericVector tempVec = sample_with_rpl(inVector,SampleSz);
 temp_samples[i] = (std::accumulate(tempVec.begin(),tempVec.end(),0.0)/SampleSz)-sample_mu;

}

std::sort(temp_samples.begin(),temp_samples.end());

double percentile_value = temp_samples[ceil(temp_samples.size() * percentile)]+sample_mu;

return percentile_value;
}
