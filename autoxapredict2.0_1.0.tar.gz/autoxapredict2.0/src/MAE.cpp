
//calculates Mean Absolute Error of 2 series.
// It is a loss function to be minimized.

#include<Rcpp.h>

#include <cmath>

using namespace Rcpp;

//[[Rcpp::export]]

double MAE(Rcpp::NumericVector actual, Rcpp::NumericVector predicted){

NumericVector cumulate;

double answer=0.0;

int kount=0;

if(actual.size() != predicted.size()){

    throw Rcpp::exception(" Both vectors must be of equal length ! ");

}else{

for(int i=0;i<actual.size();i++){

 cumulate.push_back(std::abs(actual[i] - predicted[i]));

  kount+=1;
}

answer = std::accumulate(cumulate.begin(),cumulate.end(),0.0)/kount;

}

return answer;

}
