#ifndef HOLTS_STD_PREDICTOR_H_INCLUDED
#define HOLTS_STD_PREDICTOR_H_INCLUDED

#include<Rcpp.h>

Rcpp::List Holts_STD_predictor(Rcpp::NumericMatrix Features_matrix,int iter_k_period,Rcpp::NumericVector L_t, Rcpp::NumericVector B_t);

#endif // HOLTS_STD_PREDICTOR_H_INCLUDED
