#ifndef PERCENTILE_VALUE_EXTENDED_H_INCLUDED
#define PERCENTILE_VALUE_EXTENDED_H_INCLUDED

#include<Rcpp.h>

int percentile_value_extended(Rcpp::NumericVector inVector,double percentile,int BootCycles);

#endif // PERCENTILE_VALUE_EXTENDED_H_INCLUDED
