
#include "sample_dbl.h"
#include <cmath>
#include <Rcpp.h>
#include <string>
#include <numeric>
#include "mean_errors_bootstrapper.h"
#include "median.h"
#include "features_auto_percentile_ranger.h"

/*

This module gets features' optimum percentiles from a helper function, FeaturesAutoPercentileRanger() and proceeds to use the opti-percentile
ranges per feature to recreate the feature population, and makes predictions on t+1 value for a particular feature as EITHER :
    1). A random draw from the distribution partition bounded by the opti-percentile range per feature.
    2). an Expectation defined as a MEAN.
*/

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::List spl_predictor(Rcpp::NumericMatrix FeatureMatrix, Rcpp::NumericVector L_percentiles,Rcpp::NumericVector U_percentiles,std::string MEAN_or_DRAW){

std::string kase = MEAN_or_DRAW;

if((kase !="MEAN") & (kase !="DRAW")){throw Rcpp::exception("MEAN_or_DRAW can either be MEAN or DRAW!");}

int n_col = FeatureMatrix.ncol();
int Sz = FeatureMatrix.nrow();

if(L_percentiles.size() != U_percentiles.size()){throw Rcpp::exception("vectors of percentiles must equal in length!");}

if(n_col != L_percentiles.size()){throw Rcpp::exception("Number of features must equal length of percentile vectors!");}

int draw_size = ceil(Sz/(std::log(Sz)*std::log10(Sz)));

NumericVector Next_prediction(n_col);

//      STEP 1 : Loop by feature.
for(int n = 0 ; n < n_col ; n++){
 double lower_perc  = L_percentiles[n];
 double upper_perc = U_percentiles[n];

 NumericVector feature_values = FeatureMatrix(_,n);
 NumericVector feature_population(1000); // bootstrap

 double sample_mu = round(1000*std::accumulate(feature_values.begin(),feature_values.end(),0.0)/feature_values.size())/1000;
 NumericVector ex_means = feature_values - sample_mu;

 for(int ss = 0 ; ss < 1000; ss++){
    NumericVector tempWorks = sample_with_rpl(ex_means,draw_size);
    feature_population[ss] = std::accumulate(tempWorks.begin(),tempWorks.end(),0.0)/draw_size;
 }

std::sort(feature_population.begin(), feature_population.end());
NumericVector Total_feature_population = sample_mu + feature_population;

int l_perc_pos = ceil(round(1000*lower_perc*Total_feature_population.size())/1000);
int u_perc_pos = ceil(round(1000*upper_perc*Total_feature_population.size())/1000);

NumericVector percentile_range(u_perc_pos - l_perc_pos +1);

std::iota(percentile_range.begin(),percentile_range.end(),l_perc_pos);

NumericVector data_partition = Total_feature_population[percentile_range];

if(MEAN_or_DRAW == "MEAN"){Next_prediction[n] = c_median(data_partition);}

if(MEAN_or_DRAW == "DRAW"){Next_prediction[n] = Rcpp::as<double>(sample_with_rpl(data_partition,1));}

} // n

// STEP 2 : Now that prediction vector exists for t+1, we need to find unsquared errors between it and bootstrap means of features, up to t.

NumericMatrix unsquared_errors(Sz,n_col);
NumericMatrix outMatrix(Sz+1,n_col);

for(int i = 0 ; i < Sz ; i++){
        unsquared_errors(i,_) = Next_prediction - FeatureMatrix(i,_);
        outMatrix(i,_) = FeatureMatrix(i,_);
}

outMatrix(Sz,_) = Next_prediction;

// sampling to get feature error means:
NumericVector suspended_errors;

for(int j = 0 ; j < n_col ; j++){
   //double error_mu = means_errors_bootstrap(unsquared_errors(_,j),ceil(unsquared_errors(_,j).size()/5),400,0.8)[2];
   double error_mu = means_errors_bootstrap(unsquared_errors(_,j),draw_size,1000,0.8)[2];
   suspended_errors.push_back(error_mu);
}


return Rcpp::List::create(Named("Past_N_Future",outMatrix),
                          Named("Suspended_errors",suspended_errors));



}
