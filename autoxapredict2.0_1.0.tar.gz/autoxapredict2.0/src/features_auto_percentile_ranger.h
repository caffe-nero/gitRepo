#ifndef FEATURES_AUTO_PERCENTILE_RANGER_H_INCLUDED
#define FEATURES_AUTO_PERCENTILE_RANGER_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericMatrix FeaturesAutoPercentileRanger(Rcpp::NumericMatrix FMatrix,double perc_pop = 0.50,int BootCycles = 1000);


#endif // FEATURES_AUTO_PERCENTILE_RANGER_H_INCLUDED
