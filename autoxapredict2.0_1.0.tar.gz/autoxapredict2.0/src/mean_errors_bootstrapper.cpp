#include<Rcpp.h>
#include <cmath>
#include "sample_dbl.h"
#include "median.h"

// This is a custom bootstrap function for evaluating point error as mu_error + median( mu_error - error_i).

// It works with a variable number of items to draw per cycle and a confidence interval.

// 2 Parameters have default values : 1). bool  and 2). p which is of type Rcpp::sugar::probs_t

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::List means_errors_bootstrap(Rcpp::NumericVector x_sample ,int items_per_x_sample, int Boot_Cycles, double conf_interval){

NumericVector reSample(Boot_Cycles);

double crit_val_adj = (1.00 - conf_interval)/2.0;

double lower_crit_val = 0.0 + crit_val_adj;
double upper_crit_val = 1.0 - crit_val_adj;

double sample_mu = std::accumulate(x_sample.begin(), x_sample.end(), 0.0)/x_sample.size();

for(int i = 0 ; i < Boot_Cycles  ; i++){

 NumericVector Temp_resample = sample_with_rpl(x_sample,items_per_x_sample);

 reSample[i] = ((std::accumulate(Temp_resample.begin(), Temp_resample.end(),0.0)/items_per_x_sample) - sample_mu);

}

std::sort(reSample.begin(),reSample.end());

double upper_percentile = ceil((1.00 - lower_crit_val)*reSample.size());

double lower_percentile = ceil((1.00 - upper_crit_val)*reSample.size());

NumericVector conf_interval_mean;
conf_interval_mean.push_back(sample_mu + reSample[lower_percentile]);
conf_interval_mean.push_back(sample_mu + reSample[upper_percentile]);
conf_interval_mean.push_back((conf_interval_mean[0] + conf_interval_mean[1])/2.0);

return Rcpp::List::create(Named("Mu_interval_means"           , conf_interval_mean),
                          Named("epsilon_interval_errors"     , reSample[seq(lower_percentile,upper_percentile)]),
                          Named("median_interval_errors"      , sample_mu + c_median(reSample[seq(lower_percentile,upper_percentile)])),
                          Named("epsilon_mean_interval_errors",sample_mu + reSample[seq(lower_percentile,upper_percentile)])
                          );

}
