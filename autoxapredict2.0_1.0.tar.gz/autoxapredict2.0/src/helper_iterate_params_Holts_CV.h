#ifndef HELPER_ITERATE_PARAMS_HOLTS_CV_H_INCLUDED
#define HELPER_ITERATE_PARAMS_HOLTS_CV_H_INCLUDED

#include<Rcpp.h>

Rcpp::NumericVector helper_iterator_params_Holts_CV(Rcpp::NumericVector &inVector, double &alpha, double &beta);

#endif // HELPER_ITERATE_PARAMS_HOLTS_CV_H_INCLUDED
