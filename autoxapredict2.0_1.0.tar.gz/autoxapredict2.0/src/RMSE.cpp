// Root mean square error for 2 input series.

// It's a Loss function to be minimized.

#include <Rcpp.h>

#include <cmath>

using namespace Rcpp;

//[[Rcpp::export]]

double RMSE(Rcpp::NumericVector yHat, Rcpp::NumericVector y){

    NumericVector theVec;

    int kounter=0;

if(yHat.size() != y.size()){

    throw Rcpp::exception("Both vectors must be of equal length!");

}else{


for(int i=0; i<yHat.size();i++){

 double Temp = pow((yHat[i] - y[i]),2.0);

   theVec.push_back(Temp);

   kounter+=1;

}


}


double answer=0.0;

answer = std::accumulate(theVec.begin(),theVec.end(),0.0)/kounter;

return sqrt(answer);
}
