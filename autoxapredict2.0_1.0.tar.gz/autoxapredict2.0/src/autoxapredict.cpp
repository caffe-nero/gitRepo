#include<Rcpp.h>
#include<string>
#include <cmath>
#include "sample_dbl.h"
#include "MAE.h"
#include "RMSE.h"
#include "helper_iterate_params_Holts_CV.h"
#include "helper_initial_params_Holts_STD.h"
#include "median.h"
#include "mean_errors_bootstrapper.h"
#include "candle_intervals.h"
#include "garman_klass_volatility.h"
#include "Holts_CV_predictor.h"
#include "Holts_STD_predictor.h"
#include "spl_predictor.h"

using namespace Rcpp;

//[[Rcpp::export]]

std::string autoxapredict(){

std::string HW = "Hello, world! Xapiens ~ Pricing cryptos,one alt a time";

return HW;
}
