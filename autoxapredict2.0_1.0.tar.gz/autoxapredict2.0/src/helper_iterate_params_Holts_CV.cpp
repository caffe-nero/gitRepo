// Helper function to Holts_CV_predictor()

// Use : returns Y_hat to Holts_CV_predictor() given prices and alpha-beta combination.
#include <Rcpp.h>

#include <cmath>

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericVector helper_iterator_params_Holts_CV(Rcpp::NumericVector &inVector, double &alpha, double &beta){

int inSz = inVector.size();

NumericVector Level (inSz);

NumericVector Growth (inSz);

NumericVector Y_hat(inSz);

Level[0] = inVector[1];

Growth[0] = inVector[1]-inVector[0];

Y_hat[0]  = inVector[0];

//populating vectors


for(int m = 1; m < inSz ; m++){

    Level[m] = alpha*inVector[m] + (1-alpha)*(Level[m-1] + Growth[m-1]);

    Growth[m] = beta*(Level[m] - Level[m-1]) + (1-beta)*Growth[m-1];

    Y_hat[m] = Level[m] + 1.0*Growth[m];


}
 return Y_hat;


}
