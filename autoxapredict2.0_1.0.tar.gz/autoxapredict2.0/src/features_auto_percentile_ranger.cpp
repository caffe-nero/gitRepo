#include <Rcpp.h>
#include <cmath>
#include "sample_dbl.h"
#include "median.h"

// This module takes a matrix of values of features and returns a probable percentile range centered at the median, from which
// x% of the population appears to be getting drawn from.

// default case : gives percentile ranges from which 57.5% of the data, centered around the median, is drawn from.

// x% is perc_pop : percent of population.
using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::NumericMatrix FeaturesAutoPercentileRanger(Rcpp::NumericMatrix FMatrix,double perc_pop = 0.575,int BootCycles = 1000){

if(BootCycles<1){throw Rcpp::exception("BootCycles must be >1 !!");}

int n_col = FMatrix.ncol();

NumericMatrix outMatrix(2,n_col);

for(int n = 0 ; n < n_col ; n++){

    //STEP 1 : subset vectors , determine median position and determine number of items to match perc_pop.
    NumericVector FSeries = FMatrix(_,n);
    int Sz = FSeries.size();

    // recreate population ..
    double sample_mu = std::accumulate(FSeries.begin(),FSeries.end(),0.0)/Sz;
    int SampleSz = ceil(Sz/(std::log(Sz)*std::log10(Sz)));
    NumericVector xBar = FSeries - sample_mu;
    NumericVector tempSamples(BootCycles);

    for(int i=0;i<BootCycles;i++){
    NumericVector sampled_vec = sample_with_rpl(xBar,SampleSz);
    tempSamples[i] = std::accumulate(sampled_vec.begin(),sampled_vec.end(),0.0)/sampled_vec.size();
    }

    std::sort(tempSamples.begin(),tempSamples.end());

    NumericVector inSeries = sample_mu + tempSamples; // our new fuller feature-n data.

    int rqd_probable_points =0;
    rqd_probable_points = ceil(perc_pop*inSeries.size());

    double median_value = c_median(inSeries);  // close values due to bootstrap taking means and not medians to tempSamples :)

    int med_pos =0; // median position.
    for(double xv : inSeries){
      if(xv <= median_value){med_pos+=1;}
    }

   double median_percentile = round(10*med_pos/inSeries.size())/10;

   if(median_percentile <=0.20){median_percentile = 0.20;}
   if(median_percentile >=0.80){median_percentile = 0.80;}

   int phi = 0;
   phi = ceil(10*std::min((median_percentile - 0.1),(0.9 - median_percentile)));

   double final_l_perc = median_percentile;
   double final_u_perc = median_percentile;

   for(int pp = 0; pp < phi; pp++){
        double upper_perc = median_percentile + (pp/10.0);
        double lower_perc = median_percentile - (pp/10.0);
        int u_pos_alldata = ceil(upper_perc * inSeries.size());
        int l_pos_alldata = ceil(lower_perc * inSeries.size());


            int ctr = 0;

            for(int qx = l_pos_alldata; qx < u_pos_alldata ; qx++){
                if(inSeries[qx] >= l_pos_alldata){ctr++;}
            }

            if(ctr <= rqd_probable_points){
                final_l_perc = lower_perc;
                final_u_perc = upper_perc;
            }

   } // forLoop

   outMatrix(0,n) = final_l_perc;
   outMatrix(1,n) = final_u_perc;
}//n

return outMatrix;
}
