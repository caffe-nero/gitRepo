#ifndef MEDIAN_H_INCLUDED
#define MEDIAN_H_INCLUDED

#include <Rcpp.h>

double c_median(Rcpp::NumericVector inVector);


#endif // MEDIAN_H_INCLUDED
