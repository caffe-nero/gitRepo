#ifndef MEAN_ERRORS_BOOTSTRAPPER_H_INCLUDED
#define MEAN_ERRORS_BOOTSTRAPPER_H_INCLUDED

#include<Rcpp.h>

Rcpp::List means_errors_bootstrap(Rcpp::NumericVector x_sample ,int items_per_x_sample, int Boot_Cycles, double conf_interval);


#endif // MEAN_ERRORS_BOOTSTRAPPER_H_INCLUDED
