/*

This module implements the holts algorithm esp the post param-identification step, going into forecasting.

It is the implementation of std textbook Holt's.

The implementation of the step-wise forecast algorithm takes a different route prior to how the other smoothing
algorithms are fed with data at every step ( as Features_Matrix ).In these previous implementations , the output can perpetually
self generate into the future through recursive runs.

In this implementation, Y_hat is limited to (Levels_t) + h*(Growth_t) with h being the only moving part in estimation of Y.
h is provided as { h : 1 <= i<= forecast_period } for each run.

Major differences from the varied (non - std) Holt's implementation are:
    a). a fixed level L(t) and trend b(t) in this implementation.
    b). a moving h ; not fixed to 1.0.

*/
#include <Rcpp.h>
#include <cmath>
#include "mean_errors_bootstrapper.h"
#include "helper_initial_params_Holts_STD.h"

using namespace Rcpp;

//[[Rcpp::export]]

Rcpp::List Holts_STD_predictor(Rcpp::NumericMatrix Features_matrix,int iter_k_period,Rcpp::NumericVector L_t, Rcpp::NumericVector B_t){

int cols = Features_matrix.ncol();
int rows = Features_matrix.nrow();

if((L_t.size() != cols) || (B_t.size() !=cols)){

    throw Rcpp::exception("std_holts_Future() : input vectors must be of same size as matrix columns!" );
}

//Aggregate collectors:
NumericVector loss_fn_value    (cols); //# size:= number of features.
NumericVector std_devs         (cols);

NumericMatrix residual_errors (rows , cols); // # squared errors
NumericMatrix feature_means   (rows , cols);
NumericMatrix unsquared_errors (rows,cols);

NumericVector suspended_errors;

//  Looping across features
//============================
for(int n = 0 ; n < cols ; n++){

    NumericVector y_values = Features_matrix(_ , n);

    double nLt = L_t[n];

    double nBt = B_t[n];

    NumericVector levels(rows);
    NumericVector growths(rows);

    for(int nt=0; nt<y_values.size();nt++){
         levels[nt] = nLt;
         growths[nt] = nBt;
    }

    NumericVector yHat_values(rows);

      for(int nxn= 0; nxn <rows ; nxn++){

        yHat_values[nxn] = levels[nxn] + (iter_k_period * growths[nxn]);
    }

 // read in  feature values

    NumericVector squared_errors;
    NumericVector non_squared_errors;

    double std_dev = 0.0;

    non_squared_errors = yHat_values - y_values;

    squared_errors = non_squared_errors *non_squared_errors;
    int kk = squared_errors.size();
    std_dev = sqrt(std::accumulate(squared_errors.begin(), squared_errors.end(),0.0)/kk);

residual_errors(_,n) = squared_errors;

unsquared_errors(_,n) = non_squared_errors;

feature_means(_,n) = yHat_values;

std_devs[n] = std_dev;

}//next n

//  Bootstrapping to estimate re-sampled mean of errors per feature.

NumericVector resampled_error_mu (cols);

for(int j = 0 ; j < cols ; j++){
   double error_mu = means_errors_bootstrap(unsquared_errors(_,j),ceil(unsquared_errors(_,j).size()/5),500,0.8)[2];
   suspended_errors.push_back(error_mu);
}

NumericMatrix predicted(rows+1,cols);

for(int hz = 0 ;hz < rows; hz++){
  predicted(hz,_) = Features_matrix(hz,_);
}

predicted(rows,_) = feature_means(rows-1,_);

return Rcpp::List::create(

                   Named("Std_Dev"           ,std_devs),
                   Named("Unsquared_errors"  ,unsquared_errors),
                   Named("Past_N_Future"     , predicted),
                   Named("Suspended_errors"  ,suspended_errors)

                    );

}
