#ifndef GARMAN_KLASS_VOLATILITY_H_INCLUDED
#define GARMAN_KLASS_VOLATILITY_H_INCLUDED

#include<Rcpp.h>

using namespace Rcpp;

Rcpp::NumericVector Garman_Klass_volatility(Rcpp::NumericVector price_vector,int candle_length);


#endif // GARMAN_KLASS_VOLATILITY_H_INCLUDED
