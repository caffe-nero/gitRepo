#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME:
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP _autoxapredict2_0_autoxapredict();
extern SEXP _autoxapredict2_0_c_median(SEXP);
extern SEXP _autoxapredict2_0_Candle_Intervals(SEXP, SEXP);
extern SEXP _autoxapredict2_0_FeaturesAutoPercentileRanger(SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_Garman_Klass_volatility(SEXP, SEXP);
extern SEXP _autoxapredict2_0_helper_initial_params_Holts_STD(SEXP);
extern SEXP _autoxapredict2_0_helper_iterator_params_Holts_CV(SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_Holts_CV_predictor(SEXP, SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_Holts_STD_predictor(SEXP, SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_MAE(SEXP, SEXP);
extern SEXP _autoxapredict2_0_means_errors_bootstrap(SEXP, SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_percentile_value_extended(SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_rcpp_hello_world();
extern SEXP _autoxapredict2_0_RMSE(SEXP, SEXP);
extern SEXP _autoxapredict2_0_sample_with_rpl(SEXP, SEXP, SEXP, SEXP);
extern SEXP _autoxapredict2_0_spl_predictor(SEXP, SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
    {"_autoxapredict2_0_autoxapredict",                   (DL_FUNC) &_autoxapredict2_0_autoxapredict,                   0},
    {"_autoxapredict2_0_c_median",                        (DL_FUNC) &_autoxapredict2_0_c_median,                        1},
    {"_autoxapredict2_0_Candle_Intervals",                (DL_FUNC) &_autoxapredict2_0_Candle_Intervals,                2},
    {"_autoxapredict2_0_FeaturesAutoPercentileRanger",    (DL_FUNC) &_autoxapredict2_0_FeaturesAutoPercentileRanger,    3},
    {"_autoxapredict2_0_Garman_Klass_volatility",         (DL_FUNC) &_autoxapredict2_0_Garman_Klass_volatility,         2},
    {"_autoxapredict2_0_helper_initial_params_Holts_STD", (DL_FUNC) &_autoxapredict2_0_helper_initial_params_Holts_STD, 1},
    {"_autoxapredict2_0_helper_iterator_params_Holts_CV", (DL_FUNC) &_autoxapredict2_0_helper_iterator_params_Holts_CV, 3},
    {"_autoxapredict2_0_Holts_CV_predictor",              (DL_FUNC) &_autoxapredict2_0_Holts_CV_predictor,              4},
    {"_autoxapredict2_0_Holts_STD_predictor",             (DL_FUNC) &_autoxapredict2_0_Holts_STD_predictor,             4},
    {"_autoxapredict2_0_MAE",                             (DL_FUNC) &_autoxapredict2_0_MAE,                             2},
    {"_autoxapredict2_0_means_errors_bootstrap",          (DL_FUNC) &_autoxapredict2_0_means_errors_bootstrap,          4},
    {"_autoxapredict2_0_percentile_value_extended",       (DL_FUNC) &_autoxapredict2_0_percentile_value_extended,       3},
    {"_autoxapredict2_0_rcpp_hello_world",                (DL_FUNC) &_autoxapredict2_0_rcpp_hello_world,                0},
    {"_autoxapredict2_0_RMSE",                            (DL_FUNC) &_autoxapredict2_0_RMSE,                            2},
    {"_autoxapredict2_0_sample_with_rpl",                 (DL_FUNC) &_autoxapredict2_0_sample_with_rpl,                 4},
    {"_autoxapredict2_0_spl_predictor",                   (DL_FUNC) &_autoxapredict2_0_spl_predictor,                   4},
    {NULL, NULL, 0}
};

void R_init_autoxapredict2_0(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
