#include <Rcpp.h>
#include "candle_intervals.h"
#include<cmath>

//Garman-Klass volatility

// Planned to be compiled and added to xapredict 1.0.

using namespace Rcpp;

//[[Rcpp::export]]
Rcpp::NumericVector Garman_Klass_volatility(Rcpp::NumericVector price_vector,int candle_length){

int Sz = price_vector.size();

NumericMatrix Intervals = Candle_Intervals(Sz,candle_length);

int matCols = Intervals.ncol();

NumericVector volatility(matCols);

for(int i = 0; i < matCols; i++){

   NumericVector candle_data;

    for(int k = Intervals(0,i);k<Intervals(1,i);k++){
       candle_data.push_back(price_vector[k]);
    }
            // Garman-Klass Algorithm:
            double open = candle_data[0];
            double close = candle_data[candle_data.size()-1];
            double HiPrc = candle_data[0];
            double LowPrc= HiPrc;

            for(double prc:candle_data){
                if(prc < LowPrc){LowPrc = prc;}
                if(prc > HiPrc){HiPrc = prc;}
            }

            // Normalized terms: Recall Ln(H1/H0) = Ln(H1) - Ln(H0):
            double c_norm = std::log(close) - std::log(open);
            double u_norm = std::log(HiPrc) - std::log(open);
            double d_norm = std::log(LowPrc)- std::log(open);

            volatility[i] = 0.5*pow((u_norm-d_norm),2.0)-(pow(c_norm,2.0)*(2*std::log(2.0)-1.0));
}
            return volatility;
}
